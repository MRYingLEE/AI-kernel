__import__("setuptools").setup()
