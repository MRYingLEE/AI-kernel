// Copyright (c) 2023, MRYingLEE
// Some lines of code are from Elyra Code Snippet.

import React from 'react';
import { CodeEditor, IEditorServices } from '@jupyterlab/codeeditor';
import {
  ReactWidget,
  showDialog,
  Dialog,
  WidgetTracker,
} from '@jupyterlab/apputils';
import { Button } from '@jupyterlab/ui-components';

import { Message } from '@lumino/messaging';

import { CodeSnippetService, ICodeSnippet } from './CodeSnippetService';
import { CodeSnippetWidget } from './CodeSnippetWidget';
import { SUPPORTED_LANGUAGES } from './CodeSnippetLanguages';
import { CodeSnippetEditorTags, ITag } from './CodeSnippetEditorTags';
import { showMessage } from './CodeSnippetMessage';
import { validateInputs, saveOverWriteFile } from './CodeSnippetUtilities';
// import { CodeMirrorEditor } from '@jupyterlab/codemirror';

import { VOICES } from './voices.js';
import EasySpeech from 'easy-speech';
import { MyConsole } from './controlMode';

/**
 * CSS style classes
 */
const CODE_SNIPPET_EDITOR = 'jp-codeSnippet-editor';
const CODE_SNIPPET_EDITOR_TITLE = 'jp-codeSnippet-editor-title';
const CODE_SNIPPET_EDITOR_METADATA = 'jp-codeSnippet-editor-metadata';
const CODE_SNIPPET_EDITOR_INPUT_ACTIVE = 'jp-codeSnippet-editor-active';
const CODE_SNIPPET_EDITOR_NAME_INPUT = 'jp-codeSnippet-editor-name';
const CODE_SNIPPET_EDITOR_LABEL = 'jp-codeSnippet-editor-label';
const CODE_SNIPPET_EDITOR_DESC_INPUT = 'jp-codeSnippet-editor-description';

const CODE_SNIPPET_EDITOR_TEMPLATEENGINE_INPUT =
  'jp-codeSnippet-editor-templateengine';
const CODE_SNIPPET_EDITOR_VOICENAME_INPUT = 'jp-codeSnippet-editor-voicename';
const CODE_SNIPPET_EDITOR_ICONURL_INPUT = 'jp-codeSnippet-editor-iconurl';

const CODE_SNIPPET_EDITOR_LANG_INPUT = 'jp-codeSnippet-editor-language';
const CODE_SNIPPET_EDITOR_MIRROR = 'jp-codeSnippetInput-editor';
const CODE_SNIPPET_EDITOR_INPUTAREA = 'jp-codeSnippetInputArea';
const CODE_SNIPPET_EDITOR_INPUTAREA_MIRROR = 'jp-codeSnippetInputArea-editor';

const EDITOR_DIRTY_CLASS = 'jp-mod-dirty';

export interface ICodeSnippetEditorMetadata extends ICodeSnippet {
  allSnippetTags: string[]; // all snippet tags mean all the tags that snippets have, while tags refer to those specific to a snippet
  allLangTags: string[];
  fromScratch: boolean;
}

export class CodeSnippetEditor extends ReactWidget {
  editorServices: IEditorServices;
  private editor!: CodeEditor.IEditor;
  private saved: boolean;
  private oldCodeSnippetName: string;
  private _codeSnippetEditorMetaData: ICodeSnippetEditorMetadata;
  private _hasRefreshedSinceAttach: boolean;
  // contentsService: CodeSnippetService; //Lazy loading instead to avoid non-initialized issue
  codeSnippetWidget: CodeSnippetWidget;
  tracker: WidgetTracker;

  constructor(
    editorServices: IEditorServices,
    tracker: WidgetTracker,
    codeSnippetWidget: CodeSnippetWidget,
    args: ICodeSnippetEditorMetadata
  ) {
    super();
    this.addClass(CODE_SNIPPET_EDITOR);
    // this.contentsService = CodeSnippetService;
    this.editorServices = editorServices;
    this.tracker = tracker;

    this._codeSnippetEditorMetaData = args;

    this.oldCodeSnippetName = args.name;
    this.saved = true;
    this._hasRefreshedSinceAttach = false;
    this.codeSnippetWidget = codeSnippetWidget;

    this.renderCodeInput = this.renderCodeInput.bind(this);
    this.handleInputFieldChange = this.handleInputFieldChange.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    this.activateCodeMirror = this.activateCodeMirror.bind(this);
    this.saveChange = this.saveChange.bind(this);
    this.updateSnippet = this.updateSnippet.bind(this);
    this.handleChangeOnTag = this.handleChangeOnTag.bind(this);
  }

  get codeSnippetEditorMetadata(): ICodeSnippetEditorMetadata {
    return this._codeSnippetEditorMetaData;
  }

  private deactivateEditor(
    event: React.MouseEvent<HTMLDivElement, MouseEvent>
  ): void {
    let target = event.target as HTMLElement;

    while (target && target.parentElement) {
      if (
        target.classList.contains(CODE_SNIPPET_EDITOR_MIRROR) ||
        target.classList.contains(CODE_SNIPPET_EDITOR_NAME_INPUT) ||
        target.classList.contains(CODE_SNIPPET_EDITOR_DESC_INPUT)
      ) {
        break;
      }
      target = target.parentElement;
    }

    const nameInput = document.querySelector<HTMLElement>(
      `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_NAME_INPUT}`
    );
    const descriptionInput = document.querySelector<HTMLElement>(
      `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_DESC_INPUT}`
    );
    const editor = document.querySelector<HTMLElement>(
      `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} #code-${this._codeSnippetEditorMetaData.id}`
    );

    if (target.classList.contains(CODE_SNIPPET_EDITOR_NAME_INPUT)) {
      if (nameInput) {
        this.deactivateDescriptionField(nameInput);
        if (editor instanceof Element) {
          this.deactivateCodeMirror(editor);
        }
      }
    } else if (target.classList.contains(CODE_SNIPPET_EDITOR_DESC_INPUT)) {
      if (descriptionInput) {
        this.deactivateNameField(descriptionInput);
        if (editor instanceof Element) {
          this.deactivateCodeMirror(editor);
        }
      }
    } else if (target.classList.contains(CODE_SNIPPET_EDITOR_MIRROR)) {
      if (nameInput) {
        this.deactivateNameField(nameInput);
      }
      if (descriptionInput) {
        this.deactivateDescriptionField(descriptionInput);
      }
    } else {
      if (nameInput) {
        this.deactivateNameField(nameInput);
      }
      if (descriptionInput) {
        this.deactivateDescriptionField(descriptionInput);
      }
      if (editor instanceof Element) {
        this.deactivateCodeMirror(editor);
      }
    }
  }

  private deactivateNameField(nameInput: Element): void {
    if (nameInput.classList.contains(CODE_SNIPPET_EDITOR_INPUT_ACTIVE)) {
      nameInput.classList.remove(CODE_SNIPPET_EDITOR_INPUT_ACTIVE);
    }
  }

  private deactivateDescriptionField(descriptionInput: Element): void {
    if (descriptionInput.classList.contains(CODE_SNIPPET_EDITOR_INPUT_ACTIVE)) {
      descriptionInput.classList.remove(CODE_SNIPPET_EDITOR_INPUT_ACTIVE);
    }
  }

  private activeFieldState(
    event: React.MouseEvent<HTMLInputElement, MouseEvent>
  ): void {
    const target = event.target as HTMLElement;
    if (!target.classList.contains(CODE_SNIPPET_EDITOR_INPUT_ACTIVE)) {
      target.classList.add(CODE_SNIPPET_EDITOR_INPUT_ACTIVE);
    }
  }

  onUpdateRequest(msg: Message): void {
    super.onUpdateRequest(msg);

    if (
      !this.editor &&
      document.getElementById('code-' + this._codeSnippetEditorMetaData.id)
    ) {
      const editorFactory = this.editorServices.factoryService.newInlineEditor;
      const getMimeTypeByLanguage =
        this.editorServices.mimeTypeService.getMimeTypeByLanguage;

      const newModel = new CodeEditor.Model({
        mimeType: getMimeTypeByLanguage({
          name: this._codeSnippetEditorMetaData.language,
          codemirror_mode: this._codeSnippetEditorMetaData.language,
        })
      });
      newModel.sharedModel.source = this._codeSnippetEditorMetaData.code;

      this.editor = editorFactory({
        host: document.getElementById(
          'code-' + this._codeSnippetEditorMetaData.id
        )!,
        model: newModel
      });
      this.editor.model.sharedModel.changed.connect((args: any) => {
        this._codeSnippetEditorMetaData.code = args.text.split('\n');
        if (!this.title.className.includes(EDITOR_DIRTY_CLASS)) {
          this.title.className += ` ${EDITOR_DIRTY_CLASS}`;
        }
        this.saved = false;
      });
    }
    if (this.isVisible) {
      this._hasRefreshedSinceAttach = true;
      console.log(this.editor);
      // this.editor.refresh(); //TODO: how to migrate to Jupyterlab 4?
    }
  }

  onAfterAttach(msg: Message): void {
    super.onAfterAttach(msg);

    this._hasRefreshedSinceAttach = false;
    if (this.isVisible) {
      this.update();
    }

    window.addEventListener('beforeunload', (e) => {
      if (!this.saved) {
        e.preventDefault();
        e.returnValue = '';
      }
    });
  }

  onAfterShow(msg: Message): void {
    if (!this._hasRefreshedSinceAttach) {
      this.update();
    }
  }

  /**
   * Initial focus on the editor when it gets activated!
   * @param msg
   */
  onActivateRequest(msg: Message): void {
    if (this.editor) {
      this.editor.focus();
    }
  }

  onCloseRequest(msg: Message): void {
    if (!this.saved) {
      showDialog({
        title: 'Close without saving?',
        body: (
          <p>
            {' '}
            {`"${this._codeSnippetEditorMetaData.name}" has unsaved changes, close without saving?`}{' '}
          </p>
        ),
        buttons: [
          Dialog.cancelButton(),
          Dialog.warnButton({ label: 'Discard' }),
          Dialog.okButton({ label: 'Save' }),
        ],
      }).then((response: any): void => {
        if (response.button.accept) {
          if (response.button.label === 'Discard') {
            this.dispose();
            super.onCloseRequest(msg);
          } else if (response.button.label === 'Save') {
            const name = (
              document.querySelector(
                `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_NAME_INPUT}`
              ) as HTMLInputElement
            ).value;
            const description = (
              document.querySelector(
                `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_DESC_INPUT}`
              ) as HTMLInputElement
            ).value;
            const language = (
              document.querySelector(
                `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_LANG_INPUT}`
              ) as HTMLSelectElement
            ).value;

            const validity = validateInputs(name, description, language);
            if (validity) {
              this.updateSnippet().then((value) => {
                if (value) {
                  this.dispose();
                  super.onCloseRequest(msg);
                }
              });
            }
          }
        }
      });
    } else {
      this.dispose();
      super.onCloseRequest(msg);
    }
  }

  /**
   * Visualize the editor more look like an editor
   * @param event
   */
  activateCodeMirror(
    event: React.MouseEvent<HTMLDivElement, MouseEvent>
  ): void {
    let target = event.target as HTMLElement;

    while (target && target.parentElement) {
      if (target.classList.contains(CODE_SNIPPET_EDITOR_MIRROR)) {
        break;
      }
      target = target.parentElement;
    }

    const editor = document.querySelector(
      `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} #code-${this._codeSnippetEditorMetaData.id}`
    );

    if (target.classList.contains(CODE_SNIPPET_EDITOR_MIRROR) && editor) {
      if (!editor.classList.contains('active')) {
        editor.classList.add('active');
      }
    }
  }

  deactivateCodeMirror(editor: Element): void {
    if (editor.classList.contains('active')) {
      editor.classList.remove('active');
    }
  }

  handleSelectChange(event: React.ChangeEvent<HTMLSelectElement>): void {
    this.handleFieldChange(event);
  }

  handleInputFieldChange(event: React.ChangeEvent<HTMLInputElement>): void {
    this.handleFieldChange(event);
  }

  handleFieldChange(event: React.ChangeEvent<HTMLElement>): void {
    const { name, value } = event.target as HTMLInputElement;

    switch (name) {
      case 'language':
        this._codeSnippetEditorMetaData.language = value;
        break;
      case 'templateEngine':
        this._codeSnippetEditorMetaData.templateEngine = value as
          | ''
          | 'f-string'
          | 'jinja2'
          | 'Handlebars'
          | 'ejs';
        break;
      case 'voiceName':
        this._codeSnippetEditorMetaData.voiceName = value;
        break;
      case 'iconURL':
        this._codeSnippetEditorMetaData.iconURL = value;
        break;
      // Add more cases as needed
      // case 'anotherFieldName':
      //   this._codeSnippetEditorMetaData.anotherFieldName = value;
      //   break;
      default:
        break;
    }

    if (!this.title.className.includes(EDITOR_DIRTY_CLASS)) {
      this.title.className += ` ${EDITOR_DIRTY_CLASS}`;
    }

    const target = event.target as HTMLElement;

    if (!target.classList.contains('FieldChanged')) {
      target.classList.add('FieldChanged');
    }

    this.saved = false;
  }

  saveChange(event: React.MouseEvent<HTMLElement, MouseEvent>): void {
    const name = (
      document.querySelector(
        `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_NAME_INPUT}`
      ) as HTMLInputElement
    ).value;
    const description = (
      document.querySelector(
        `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_DESC_INPUT}`
      ) as HTMLInputElement
    ).value;
    const language = (
      document.querySelector(
        `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_LANG_INPUT}`
      ) as HTMLSelectElement
    ).value;

    const validity = validateInputs(name, description, language);
    if (validity) {
      this.updateSnippet();
    }
  }

  async voiceTest(
    event: React.MouseEvent<HTMLElement, MouseEvent>
  ): Promise<void> {
    let code: string;

    if (Array.isArray(this._codeSnippetEditorMetaData.code)) {
      code = this._codeSnippetEditorMetaData.code.join('\n');
    } else {
      code = this._codeSnippetEditorMetaData.code;
    }

    const voiceName = this._codeSnippetEditorMetaData.voiceName;

    if (window.speechSynthesis.speaking) {
      // if (EasySpeech.status().status.includes("speak") ){
      EasySpeech.cancel();
    } else {
      // const [cell_text, focalcode_text, stdout_text, result_text, stderr_text] =
      //   get_focal_data(siteName);

      MyConsole.log('To be spoke:', code);

      const voices = EasySpeech.voices();

      MyConsole.log('easy voices length:', voices.length);

      // for (let i = 0; i < voices.length; i++) {
      //   if (voices[i].lang.startsWith("en-US")) {
      //     MyConsole.log("voice name:", voices[i].name);
      //   }
      // }
      // const lang = await browserDetectLanguage(code);
      // MyConsole.log('Lang:', lang);

      let microsoftVoice = voices.find(
        (voice: any) => voice.name === voiceName
      );
      try {
        if (microsoftVoice === undefined) {
          // if (lang === 'en') {
          //   microsoftVoice = voices.find(
          //     (voice) => voice.name === defaultENVoiceName
          //   );
          // } else if (lang === 'zh') {
          //   microsoftVoice = voices.find(
          //     (voice) =>
          //       voice.name ===
          //       'Microsoft Xiaoxiao Online (Natural) - Chinese (Mainland)'
          //   );
          // }
          microsoftVoice = voices[0];
        }
      } catch {
        microsoftVoice = voices[0];
      }

      await EasySpeech.speak({
        text: code,
        voice: microsoftVoice, // optional, will use a default or fallback
        pitch: 1,
        rate: 1,
        volume: 1,
        // there are more events, see the API for supported events
        boundary: (e: any) => MyConsole.debug('boundary reached'),
      });
    }
  }

  async updateSnippet(): Promise<boolean> {
    const name = (
      document.querySelector(
        `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_NAME_INPUT}`
      ) as HTMLInputElement
    ).value;
    const description = (
      document.querySelector(
        `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_DESC_INPUT}`
      ) as HTMLInputElement
    ).value;
    const language = (
      document.querySelector(
        `.${CODE_SNIPPET_EDITOR}-${this._codeSnippetEditorMetaData.id} .${CODE_SNIPPET_EDITOR_LANG_INPUT}`
      ) as HTMLSelectElement
    ).value;

    this._codeSnippetEditorMetaData.name = name;
    this._codeSnippetEditorMetaData.description = description;
    this._codeSnippetEditorMetaData.language = language;

    if (name.startsWith('@')) {
      if (this._codeSnippetEditorMetaData.tags) {
        this._codeSnippetEditorMetaData.tags.push('character');
      } else {
        this._codeSnippetEditorMetaData.tags = ['character'];
      }
    } else {
      this._codeSnippetEditorMetaData.tags =
        this._codeSnippetEditorMetaData.tags?.filter((tag) => tag !== 'character');
    }

    if (name.startsWith('/')) {
      if (this._codeSnippetEditorMetaData.tags) {
        this._codeSnippetEditorMetaData.tags.push('action');
      } else {
        this._codeSnippetEditorMetaData.tags = ['action'];
      }
    } else {
      this._codeSnippetEditorMetaData.tags =
        this._codeSnippetEditorMetaData.tags?.filter((tag) => tag !== 'action');
    }

    const newName = this._codeSnippetEditorMetaData.name;
    const oldName = this.oldCodeSnippetName;
    const newSnippet: ICodeSnippet = {
      name: this._codeSnippetEditorMetaData.name,
      description: this._codeSnippetEditorMetaData.description,
      language: this._codeSnippetEditorMetaData.language,
      code: this._codeSnippetEditorMetaData.code,
      id: this._codeSnippetEditorMetaData.id,
      tags: this._codeSnippetEditorMetaData.tags,
      templateEngine: this._codeSnippetEditorMetaData.templateEngine,
      voiceName: this._codeSnippetEditorMetaData.voiceName,
      iconURL: this._codeSnippetEditorMetaData.iconURL,
    };

    if (Array.isArray(newSnippet.code)) {
      newSnippet.code = newSnippet.code.join('\n');
    }

    this._codeSnippetEditorMetaData;

    // console.log('newSnippet:', newSnippet);
    const isDuplicatName = CodeSnippetService.duplicatedName(newName);

    // update new name as an old name
    this.oldCodeSnippetName = this._codeSnippetEditorMetaData.name;

    // add new snippet
    if (this._codeSnippetEditorMetaData.fromScratch) {
      if (isDuplicatName) {
        const oldSnippet = CodeSnippetService.getSnippetByName(newName)[0];
        await saveOverWriteFile(oldSnippet, newSnippet);
      } else {
        CodeSnippetService.addSnippet(newSnippet).then((res: boolean) => {
          if (!res) {
            console.log('Error in adding snippet');
            return false;
          }
        });
        showMessage('confirm');
      }
    }
    // modify existing snippet
    else {
      if (newName !== oldName) {
        if (isDuplicatName) {
          // overwrite
          const oldSnippet = CodeSnippetService.getSnippetByName(newName)[0];
          await saveOverWriteFile(
            // CodeSnippetService,
            oldSnippet,
            newSnippet
          ).then((res: boolean) => {
            if (res) {
              // get the id of snippet you are editting
              const removedSnippet =
                CodeSnippetService.getSnippetByName(oldName)[0];

              // delete the one you are editing
              CodeSnippetService.deleteSnippet(removedSnippet.id);
            } else {
              return false;
            }
          });
        }
      }
      CodeSnippetService.modifyExistingSnippet(oldName, newSnippet).then(
        (res: boolean) => {
          if (!res) {
            console.log('Error in modifying snippet');
            return false;
          }
        }
      );
    }

    this.saved = true;

    // remove the dirty state
    this.title.className = this.title.className.replace(
      ` ${EDITOR_DIRTY_CLASS}`,
      ''
    );

    if (this._codeSnippetEditorMetaData.language !== 'Markdown') {
      this.title.label =
        '[' +
        this._codeSnippetEditorMetaData.language +
        '] ' +
        this._codeSnippetEditorMetaData.name;
    } else {
      this.title.label = this._codeSnippetEditorMetaData.name;
    }
    // change label

    if (!this._codeSnippetEditorMetaData.fromScratch) {
      // update tracker
      this.tracker.save(this);
    }

    // update the display in code snippet explorer
    this.codeSnippetWidget.updateCodeSnippetWidget();

    // close editor if it's from scratch
    if (this._codeSnippetEditorMetaData.fromScratch) {
      this.dispose();
    }
    return true;
  }

  handleChangeOnTag(tags: ITag[]): void {
    if (!this.title.className.includes(EDITOR_DIRTY_CLASS)) {
      this.title.className += ` ${EDITOR_DIRTY_CLASS}`;
    }

    this._codeSnippetEditorMetaData.tags = tags
      .filter((tag: ITag) => tag.clicked)
      .map((tag: ITag) => tag.name);
    this._codeSnippetEditorMetaData.allSnippetTags = tags.map(
      (tag: ITag) => tag.name
    );

    this.saved = false;
  }

  handleOnBlur(event: React.FocusEvent<HTMLInputElement>): void {
    const target = event.target as HTMLElement;
    if (!target.classList.contains('touched')) {
      target.classList.add('touched');
    }
  }

  /**
   * TODO: clean CSS style class - "Use constant"
   */
  renderCodeInput(): React.ReactElement {
    return (
      <section
        className={CODE_SNIPPET_EDITOR_INPUTAREA_MIRROR}
        onMouseDown={this.activateCodeMirror}
      >
        <div
          className={CODE_SNIPPET_EDITOR_MIRROR}
          id={'code-' + this._codeSnippetEditorMetaData.id.toString()}
        ></div>
      </section>
    );
  }

  renderLanguages(fromScratch: boolean): React.ReactElement {
    SUPPORTED_LANGUAGES.sort();
    let language: string;
    if (fromScratch) {
      language = 'Markdown';
    } else {
      language = this._codeSnippetEditorMetaData.language;
      if (language === undefined || !SUPPORTED_LANGUAGES.includes(language)) {
        language = 'Markdown';
      }
    }

    return (
      <div className="flexAlignColumn">
        <label className={CODE_SNIPPET_EDITOR_LABEL}>Language (required)</label>
        <select
          className={CODE_SNIPPET_EDITOR_LANG_INPUT}
          name="language"
          title="Language" // Add a title attribute as a label
          defaultValue={language}
          onChange={this.handleSelectChange}
          // onChange={this.handleInputFieldChange}
        >
          {SUPPORTED_LANGUAGES.map((lang) => this.renderAnOptions(lang))}
        </select>
      </div>
    );
  }

  renderTemplateEngine(): React.ReactElement {
    return (
      <div className="flexAlignColumn">
        <label className={CODE_SNIPPET_EDITOR_LABEL}>
          templateEngine (optional)
        </label>
        <select
          className={CODE_SNIPPET_EDITOR_TEMPLATEENGINE_INPUT}
          title="Template Engine" // Add a title attribute as a label
          name="templateEngine"
          defaultValue={this._codeSnippetEditorMetaData.templateEngine}
          onChange={this.handleSelectChange}
          // onChange={this.handleInputFieldChange}
        >
          {[
            this.renderAnOptions(''),
            // renderLanguageOptions('(None)'),
            this.renderAnOptions('Handlebars'),
          ]}
        </select>
      </div>
    );
  }

  renderVoiceNames(value: string | undefined): React.ReactElement {
    // const [selectedVoice, setSelectedVoice] = useState(
    //   voiceName
    // );
    // const [utterance, setUtterance] = useState<null | SpeechSynthesisUtterance>(
    //   null
    // );

    // const voices = speechSynthesis.getVoices(); //TODO： To make it in the outter code

    // while (VOICES.length === 0) {
    //   voicesReady.then((voices) => {
    //     VOICES = voices; // This should now log the list of voices
    //   });
    //   sleep(1);
    // }

    const voices = VOICES;

    // useEffect(() => {
    //   if (selectedVoice) {
    //     const utterThis = new SpeechSynthesisUtterance('Hello World');
    //     utterThis.voice = voices.find((voice) => voice.name === selectedVoice);
    //     setUtterance(utterThis);
    //   }
    // }, [selectedVoice]);

    //TODO： To make it in the outter code
    const voiceOptions = voices.reduce(
      (acc: { [key: string]: any[] }, voice) => {
        if (!acc[voice.lang]) {
          acc[voice.lang] = [];
        }
        acc[voice.lang].push({
          name: voice.name,
          language: voice.lang,
        });
        return acc;
      },
      {}
    );

    // const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    //   // setSelectedVoice(e.target.value);
    //   this._codeSnippetEditorMetaData.voiceName = e.target.value;
    // };

    return (
      <div className="flexAlignColumn">
        <label className={CODE_SNIPPET_EDITOR_LABEL}>Voice (optional)</label>
        <select
          className={CODE_SNIPPET_EDITOR_VOICENAME_INPUT}
          title="Select Voice"
          name="voiceName"
          defaultValue={this._codeSnippetEditorMetaData.voiceName}
          // onChange={handleVoiceChange}
          onChange={this.handleSelectChange}
          aria-label="Select Voice"
        >
          {Object.entries(voiceOptions).map(([lang, voices]) => (
            <optgroup label={lang} key={lang}>
              {(voices as SpeechSynthesisVoice[]).map(
                (voice: SpeechSynthesisVoice) => (
                  <option key={voice.name} value={voice.name}>
                    {voice.name}
                  </option>
                )
              )}
            </optgroup>
          ))}
        </select>
      </div>
    );
  }
  // renderLanguageOptions(option: string): JSX.Element {
  //   return <option key={option} value={option} />;
  // }

  renderAnOptions(option: string): JSX.Element {
    return (
      <option key={option} value={option}>
        {option}
      </option>
    );
  }

  //TODO: to unhide language part later
  render(): React.ReactElement {
    const fromScratch = this._codeSnippetEditorMetaData.fromScratch;
    return (
      <div
        className={CODE_SNIPPET_EDITOR_INPUTAREA}
        onMouseDown={(
          event: React.MouseEvent<HTMLDivElement, MouseEvent>
        ): void => {
          this.deactivateEditor(event);
        }}
      >
        <span className={CODE_SNIPPET_EDITOR_TITLE}>
          {fromScratch
            ? // To hide the code snippets part for temp
              // ? 'New Code Snippet / chatting character, action'
              // : 'Edit Code Snippet / chatting character, action'}
              'New character / action'
            : 'Edit character / action'}
        </span>
        <section className={CODE_SNIPPET_EDITOR_METADATA}>
          <label className={CODE_SNIPPET_EDITOR_LABEL}>
            Name (required) (Only ENGLISH characters allowed)
            {/* <p />
            <p>
              {' '}
              Name starting with &apos@&apos means a character in chatting. Such
              as &apos@Newton&apos
            </p>
            <p>
              {' '}
              Name starting with &apos/&apos means an action in chatting. Such
              as &apos/toEnglish&apos
            </p> */}
          </label>
          <input
            className={CODE_SNIPPET_EDITOR_NAME_INPUT}
            defaultValue={this._codeSnippetEditorMetaData.name}
            placeholder={'Ex. @Newton, or /toEnglish'}
            type="text"
            required
            onMouseDown={(
              event: React.MouseEvent<HTMLInputElement, MouseEvent>
            ): void => this.activeFieldState(event)}
            onChange={(event: React.ChangeEvent<HTMLInputElement>): void => {
              this.handleInputFieldChange(event);
            }}
            onBlur={this.handleOnBlur}
          ></input>
          <label className={CODE_SNIPPET_EDITOR_LABEL}>
            Description (optional)
          </label>
          <input
            className={CODE_SNIPPET_EDITOR_DESC_INPUT}
            defaultValue={this._codeSnippetEditorMetaData.description}
            placeholder={'Description'}
            type="text"
            onMouseDown={(
              event: React.MouseEvent<HTMLInputElement, MouseEvent>
            ): void => this.activeFieldState(event)}
            onChange={(event: React.ChangeEvent<HTMLInputElement>): void => {
              this.handleInputFieldChange(event);
            }}
            onBlur={this.handleOnBlur}
          ></input>
          {/* <span className={CODE_SNIPPET_EDITOR_LABEL}>Code</span> */}
          <span className={CODE_SNIPPET_EDITOR_LABEL}>Prompt</span>
          {this.renderCodeInput()}
          <label className={CODE_SNIPPET_EDITOR_LABEL}>Tags</label>
          <CodeSnippetEditorTags
            allSnippetTags={
              this._codeSnippetEditorMetaData.allSnippetTags
                ? this._codeSnippetEditorMetaData.allSnippetTags.map(
                  (tag: string): ITag => ({
                    name: tag,
                    clicked:
                      this._codeSnippetEditorMetaData.tags &&
                        this._codeSnippetEditorMetaData.tags.includes(tag)
                        ? true
                        : false,
                  })
                )
                : []
            }
            langTags={this._codeSnippetEditorMetaData.allLangTags}
            handleChange={this.handleChangeOnTag}
          />
          {/* <label className={CODE_SNIPPET_EDITOR_LABEL}>
            Language (required)
          </label> */}
          {this.renderLanguages(fromScratch)}
          {/* <label className={CODE_SNIPPET_EDITOR_LABEL}>
            templateEngine (optional)
          </label> */}
          {this.renderTemplateEngine()}
          <div className="flexAlignColumn">
            <label className={CODE_SNIPPET_EDITOR_LABEL}>
              Icon URL (optional)
            </label>
            <input
              className={CODE_SNIPPET_EDITOR_ICONURL_INPUT}
              defaultValue={this._codeSnippetEditorMetaData.iconURL}
              placeholder={'iconURL, such as https://AILearn.live/icon.jpg'}
              type="text"
              onMouseDown={(
                event: React.MouseEvent<HTMLInputElement, MouseEvent>
              ): void => this.activeFieldState(event)}
              onChange={(event: React.ChangeEvent<HTMLInputElement>): void => {
                this.handleInputFieldChange(event);
              }}
              onBlur={this.handleOnBlur}
            ></input>
          </div>
          {/* <label className={CODE_SNIPPET_EDITOR_LABEL}>
            Voice Name (optional)
          </label> */}
          {this.renderVoiceNames(this._codeSnippetEditorMetaData.voiceName)}
        </section>
        <div className="flexAlignRight">
          <Button
            className="voiceBtn"
            onClick={async (event: React.MouseEvent<HTMLElement, MouseEvent>) =>
              await this.voiceTest(event)
            }
          >
            Voice Test
          </Button>
          <Button className="saveBtn" onClick={this.saveChange}>
            {fromScratch ? 'Create & Close' : 'Save'}
          </Button>
        </div>
      </div>
    );
  }
}
