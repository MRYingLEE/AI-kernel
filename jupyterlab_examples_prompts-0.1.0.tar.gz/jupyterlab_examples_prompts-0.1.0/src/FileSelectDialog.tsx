import React, { ChangeEvent, createRef } from 'react';
import { CodeSnippetService } from './CodeSnippetService';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { FileBrowserModel } from '@jupyterlab/filebrowser';
import { IDocumentManager } from '@jupyterlab/docmanager/lib/tokens';
// import { UUID } from '@lumino/coreutils';

interface IFileSelectDialogProps {
  app: JupyterFrontEnd;
  documentManager: IDocumentManager;
}

class FileSelectDialog extends React.Component<IFileSelectDialogProps> {
  // private _contents;
  // private _serviceManager;
  private _documentManager;
  constructor(props: IFileSelectDialogProps) {
    super(props);
    // const { serviceManager } = props.app;
    // this._serviceManager = serviceManager;
    // const { contents } = serviceManager;
    // this._contents = contents;
    this._documentManager = props.documentManager;
  }

  private fileInputRef = createRef<HTMLInputElement>();

  handleFileSelect = async (
    event: ChangeEvent<HTMLInputElement>
  ): Promise<void> => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach(async (file) => {
        if (file.name.endsWith('.json')) {
          try {
            // const model = await CodeSnippetContentsService.getInstance().load(
            //   file.path
            // );

            const browserModel = new FileBrowserModel({
              manager: this._documentManager,
            });

            //TODO: We need to make sure the directory exists at first
            const tmpPath = '/prompts/';
            const currentPath = browserModel.path;
            browserModel.cd(tmpPath);
            const model = await browserModel.upload(file);

            try {
              // const model = await this._contents.get(file.name, {
              //   content: true,
              // });

              // const snippet = JSON.parse(model.content);
              const snippet = model.content;
              if (Array.isArray(model.content.code)) {
                snippet.code = model.content.code.join('\n');
              }

              // console.log(snippet);
              // this.codeSnippetService.codeSnippetList.push(snippet); //TODO: We may use name as key to insert an item.
              CodeSnippetService.addSnippet(snippet);
              console.log(model);
            } catch (e: any) {
              console.log(e);
            }

            browserModel.manager.deleteFile(model.path);
            browserModel.cd(currentPath);
          } catch (error) {
            // const snippet : ICodeSnippet = {
            //   name: UUID.uuid4(),
            //   description: `Error processing file ${file.name}: ${error}`,
            //   language: 'Markdown',
            //   code: ,
            //   id: CodeSnippetService.length,
            //   tags: [],
            //   templateEngine: '',
            //   voiceName: '',
            //   iconURL: '',
            // };
            // CodeSnippetService.addSnippet(snippet);
            console.error(`Error processing file ${file.name}: ${error}`);
          }
        }
      });
    }
  };

  triggerFileSelect = (): void => {
    this.fileInputRef.current?.click();
  };

  render(): React.JSX.Element {
    return (
      <input
        type="file"
        multiple
        onChange={this.handleFileSelect}
        ref={this.fileInputRef}
        style={{ display: 'none' }}
      />
    );
  }
}

export default FileSelectDialog;