// Copyright (c) 2023, MRYingLEE

import { ContentsManager, Contents } from '@jupyterlab/services';

/**
 * Singleton contentsService class
 */
export class CodeSnippetContentsService {
  // drive: Drive;
  contentsManager: ContentsManager;
  private static instance: CodeSnippetContentsService;

  // Here we switch to use jupyter compatible conents manager

  // private constructor() {
  //   const drive = new Drive({ name: 'snippetDrive ' });
  //   const contentsManager = new ContentsManager({ defaultDrive: drive });
  //   this.drive = drive;
  //   this.contentsManager = contentsManager;
  // }

  private constructor(contentsManager: ContentsManager) {
    this.contentsManager = contentsManager;
  }

  static getInstance(): CodeSnippetContentsService {
    if (!this.instance) {
      console.error('CodeSnippetContentsService is not initialized.');
    }
    return this.instance;
  }

  static init(contentsManager: ContentsManager): CodeSnippetContentsService {
    if (!this.instance) {
      this.instance = new CodeSnippetContentsService(contentsManager);
    }
    return this.instance;
  }

  /**
   * Create a file/directory if it does not exist. Otherwise, save the change in a file/directory in the given path
   * @param path path to a file/directory
   * @param options options that specify if it's a file or directory and additial information
   * Usage: save('snippets', { type: 'directory' }) to create/save a directory
   *        save('snippets/test.json', {type: 'file', format: 'text', content: 'Lorem ipsum dolor sit amet'})
   */
  async save(
    path: string,
    options?: Partial<Contents.IModel>
  ): Promise<Contents.IModel> {
    try {
      const changedModel = await this.contentsManager.save(path, options);
      return changedModel;
    } catch (error) {
      throw error;
    }
  }

  async load(
    path: string,
    options?: Partial<Contents.IModel>
  ): Promise<Contents.IModel> {
    try {
      const changedModel = await this.contentsManager.get(path, options);
      return changedModel;
    } catch (error) {
      throw error;
    }
  }
}
