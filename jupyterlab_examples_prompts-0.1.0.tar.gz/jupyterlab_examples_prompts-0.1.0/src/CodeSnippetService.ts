import { JupyterFrontEnd } from '@jupyterlab/application';
import { Settings } from '@jupyterlab/settingregistry';
import { JSONArray, JSONExt, PartialJSONValue } from '@lumino/coreutils';

import { CodeSnippetWidget } from './CodeSnippetWidget';
import { Contents, ContentsManager } from '@jupyterlab/services';
import { CodeSnippetContentsService } from './CodeSnippetContentsService';
import { JSONValue } from '@lumino/coreutils';

//TODO: To make it compatible to prompt compatible, add speech, icon
export interface ICodeSnippet {
  name: string;
  description?: string;
  language: string; //TODO:To make prompt as a kind of language, such as Handlebar, JINJIA2, or other templating languages
  // code separated by a new line. This is a must for a prompt could be long.
  code: string;
  id: number; // for UI purpose
  tags?: string[];

  templateEngine?: '' | 'f-string' | 'jinja2' | 'Handlebars' | 'ejs'; //such as Handlebar, JINJIA2, or other templating languages
  voiceName?: string; // Role/Characters specific //TODO: to make it save along with lang and country, so that if no assigned voice available, we can fallback to a similar voice.
  iconURL?: string;
  //NatualLanguage?: string; // Role/Characters specific
}
const aiPrompt = `
**Your name is AI and you are a good tutor. You are helping the user with their task.**
Here is the task or question that the user is asking you:
`;

const ICodeSnippet_ai: ICodeSnippet = {
  name: '/ai',
  description: '',
  language: 'Markdown',
  code: aiPrompt,
  id: 0,
  tags: ['default'],
  templateEngine: '',
  voiceName: '',
  iconURL: '',
};

const chatPrompt = `
**Your name is AI and you are a good tutor. You are helping the user with their task.**
`;

const ICodeSnippet_chat: ICodeSnippet = {
  name: '@chat',
  description: '',
  language: 'Markdown',
  code: chatPrompt,
  id: 1,
  tags: ['default'],
  templateEngine: '',
  voiceName: '',
  iconURL: '',
};

export class CodeSnippetService {
  private settingManager: Settings; //TODO: We may don't need a setting manager
  private static codeSnippetService: CodeSnippetService; //Lazy loading instead to avoid non-initialized issue
  private codeSnippetList: ICodeSnippet[]; //TODO: To make it a dictionary
  // private _app: JupyterFrontEnd;
  private constructor(settings: Settings, app: JupyterFrontEnd) {
    if (CodeSnippetService.codeSnippetService === undefined) {
      CodeSnippetService.codeSnippetService = this;
    }
    console.log('CodeSnippetService.codeSnippetService is initialized.');
    
    this.codeSnippetList = [];
    
    this.codeSnippetList.push(ICodeSnippet_ai); //To make sure there are default prompts
    this.codeSnippetList.push(ICodeSnippet_chat); //To make sure there are default prompts

    this.settingManager = settings;
    // this._app = app;
    // when user changes the snippets using settingsEditor
    this.settingManager.changed.connect(async (plugin) => {
      const newCodeSnippetList = plugin.get('snippets').user || [];

      if (
        !JSONExt.deepEqual(
          newCodeSnippetList,
          this.codeSnippetList as unknown as PartialJSONValue
        )
      ) {
        this.codeSnippetList = this.convertToICodeSnippetList(
          newCodeSnippetList as JSONArray
        );

        const leftWidgets = app.shell.widgets('left');

        for (const widget of leftWidgets) {
          if (widget instanceof CodeSnippetWidget) {
            widget.updateCodeSnippetWidget();
            break;
          }
        }

        // order code snippet and sync it with setting
        // this.orderSnippets();

        CodeSnippetService.orderSnippets_internal(this);
        await plugin
          .set('snippets', this.codeSnippetList as unknown as JSONValue[])
          .catch((e) => {
            console.log(
              'Error in syncing orders of snippets with those in settings'
            );
            console.log(e);
          });
      }
    });

    // load user's saved snippets
    if (this.settingManager.get('snippets').user) {
      const userSnippets = this.convertToICodeSnippetList(
        this.settingManager.get('snippets').user as JSONArray
      );

      userSnippets.forEach((snippet) => {
        CodeSnippetService.addSnippet(snippet);
      });
    }

    // set default preview font size
    if (this.settingManager.get('snippetPreviewFontSize').user === undefined) {
      const defaultFontSize: JSONValue = this.settingManager.default('snippetPreviewFontSize') as unknown as JSONValue;
      if (typeof defaultFontSize === 'number') {
        this.settingManager.set('snippetPreviewFontSize', [defaultFontSize]);
      }
    }
  }

  private convertToICodeSnippetList(snippets: JSONArray): ICodeSnippet[] {
    const snippetList: ICodeSnippet[] = [];

    try {
      if (snippets) {
        snippets.forEach((snippet) => {
          const newSnippet = snippet as unknown as ICodeSnippet;
          snippetList.push(newSnippet);
        });
      }
      // eslint-disable-next-line no-empty
    } finally {
    }
    return snippetList;
  }

  private static getCodeSnippetService(): CodeSnippetService {
    if (!CodeSnippetService.codeSnippetService) {
      console.error('CodeSnippetService is not initialized!');
      // CodeSnippetService.initCodeSnippetService(this.settings, this._app);
    }
    return CodeSnippetService.codeSnippetService;
  }

  static async initCodeSnippetService(
    settings: Settings,
    app: JupyterFrontEnd
  ): Promise<void> {
    if (!CodeSnippetService.codeSnippetService) {
      CodeSnippetService.codeSnippetService = new CodeSnippetService(
        settings,
        app
      );

      // We intend to clear all code snippets because we prefer to use fake fs as the trusted source instead of IndexedDB directly

      // if (CodeSnippetService.codeSnippetService.codeSnippetList === undefined) {
      //   CodeSnippetService.codeSnippetService.codeSnippetList = [];
      // }
      //TODO: we may use both the settings and the file system as sources
      if (
        CodeSnippetService.getCodeSnippetService()?.codeSnippetList ===
        undefined
      ) {
        CodeSnippetService.codeSnippetService.codeSnippetList = [];
        CodeSnippetService.codeSnippetService.codeSnippetList.push(
          ICodeSnippet_ai
        ); //To make sure there are default prompts
        CodeSnippetService.codeSnippetService.codeSnippetList.push(
          ICodeSnippet_chat
        ); //To make sure there are default prompts
      }

      const { serviceManager } = app;
      const { contents } = serviceManager;

      CodeSnippetContentsService.init(contents as ContentsManager);

      //Testing Conclusion:
      // 1. only path with "/" instead of "\\" acceptable by the contents manager
      // 2. const folders = ['/snippets/', '/snippets']; // both works in the same way

      // We don't load automatically for user could be confused. Also, it is a big challenge to keep the files sync up with snippets in memory.
      const folders = ['/snippets/', '/prompts/'];
      for (const folder in folders) {
        try {
          // this.codeSnippetService.codeSnippetList =
          await CodeSnippetService.load(contents as ContentsManager, folders[folder]);
          // console.log(
          //   folders[folder],
          //   ' has ',
          //   this.codeSnippetService.codeSnippetList.length,
          //   'items.'
          // );
        } catch (error) {
          console.log(error);
        }
      }
    }
  }
  static async load(
    contents: ContentsManager,
    folderPath: string
  ): Promise<void> {
    //Promise<ICodeSnippet[]> {
    // const snippets: ICodeSnippet[] = [];

    // console.log(folderPath);

    // Get the directory listing
    // const files = await serviceManager.contents.get(folderPath);
    const files = await contents.get(folderPath, { content: true });

    // files.content is an array of file models
    for (const file of files.content) {
      if (
        (file as Contents.IModel).type === 'file' &&
        file.path.endsWith('.json')
      ) {
        try {
          // const model = await CodeSnippetContentsService.getInstance().load(
          //   file.path
          // );
          const model = await contents.get(file.path, {
            content: true,
          });

          // const snippet = JSON.parse(model.content);
          const snippet = model.content;
          if (Array.isArray(model.content.code)) {
            snippet.code = model.content.code.join('\n');
          }

          // console.log(snippet);
          // this.codeSnippetService.codeSnippetList.push(snippet); //TODO: We may use name as key to insert an item.
          CodeSnippetService.addSnippet(snippet);
          // console.log(model);
        } catch (error) {
          console.error(`Error processing file ${file.path}: ${error}`);
        }
      }
    }

    // return snippets;
  }

  static get settings(): Settings {
    return CodeSnippetService.getCodeSnippetService().settingManager;
  }

  // get snippets(): ICodeSnippet[] {
  //   return this.codeSnippetList;
  // }

  static get snippets(): ICodeSnippet[] {
    return this.getCodeSnippetService()?.codeSnippetList;
  }

  static getSnippetByName(snippetName: string): ICodeSnippet[] {
    if (
      CodeSnippetService.getCodeSnippetService().codeSnippetList === undefined
    ) {
      return [];
    }
    return CodeSnippetService.getCodeSnippetService().codeSnippetList.filter(
      (snippet) => snippet.name.toLowerCase() === snippetName.toLowerCase()
    );
  }

  static getUniqueSnippetByName(snippetName: string): ICodeSnippet {
    const snippets = CodeSnippetService.getSnippetByName(snippetName);

    // if (snippets.length === 0) {
    //   return undefined;
    // }
    return snippets[0];
  }

  static async addSnippet(snippet: ICodeSnippet): Promise<boolean> {
    if (CodeSnippetService.duplicatedName(snippet.name)) {
      return CodeSnippetService.modifyExistingSnippet(snippet.name, snippet);
    } else {
      return CodeSnippetService.addSnippet_internal(snippet);
    }
  }

  static async addSnippet_internal(snippet: ICodeSnippet): Promise<boolean> {
    const globalService = CodeSnippetService.getCodeSnippetService();
    if (globalService.codeSnippetList === undefined) {
      globalService.codeSnippetList = [];
      globalService.codeSnippetList.push(ICodeSnippet_ai); //To make sure there are default prompts
      globalService.codeSnippetList.push(ICodeSnippet_chat); //To make sure there are default prompts
    }
    const id = snippet.id;
    globalService.codeSnippetList.splice(id, 0, snippet);

    const numSnippets = globalService.codeSnippetList.length;

    // update id's of snippets.
    let i = id + 1;
    for (; i < numSnippets; i++) {
      globalService.codeSnippetList[i].id += 1;
    }

    await globalService.settingManager
      .set(
        'snippets',
        globalService.codeSnippetList as unknown as JSONValue
      )
      .catch((_) => {
        return false;
      });
    return true;
  }

  static async deleteSnippet(id: number): Promise<boolean> {
    const globalService = CodeSnippetService.getCodeSnippetService();

    if (globalService.codeSnippetList === undefined) {
      return false;
    }
    let numSnippets = globalService.codeSnippetList.length;

    // should never satisfy this condition
    if (id >= numSnippets) {
      console.log('error in codeSnippetService');
    }

    if (id === numSnippets - 1) {
      globalService.codeSnippetList.pop();
    } else {
      globalService.codeSnippetList.splice(id, 1);

      numSnippets = globalService.codeSnippetList.length;
      let i = id;
      for (; i < numSnippets; i++) {
        globalService.codeSnippetList[i].id -= 1;
      }
    }

    await globalService.settingManager
      .set(
        'snippets',
        globalService.codeSnippetList as unknown as JSONValue
      )
      .catch((_) => {
        return false;
      });

    return true;
  }

  static async renameSnippet(
    oldName: string,
    newName: string
  ): Promise<boolean> {
    const globalService = CodeSnippetService.getCodeSnippetService();

    if (globalService.codeSnippetList === undefined) {
      return false;
    }

    for (const snippet of globalService.codeSnippetList) {
      if (snippet.name === oldName) {
        snippet.name = newName;
        break;
      }
    }
    await globalService.settingManager
      .set(
        'snippets',
        globalService.codeSnippetList as unknown as JSONValue
      )
      .catch((_) => {
        return false;
      });
    return true;
  }

  static duplicatedName(newName: string): boolean {
    const globalService = CodeSnippetService.getCodeSnippetService();
    if (globalService === undefined) {
      return false;
    }
    if (globalService.codeSnippetList === undefined) {
      return false;
    }
    for (const snippet of globalService.codeSnippetList) {
      if (snippet.name.toLowerCase() === newName.toLowerCase()) {
        return true;
      }
    }
    return false;
  }

  static async modifyExistingSnippet(
    oldName: string,
    newSnippet: ICodeSnippet
  ): Promise<boolean> {
    const globalService = CodeSnippetService.getCodeSnippetService();

    if (globalService.codeSnippetList === undefined) {
      return false;
    }
    for (const snippet of globalService.codeSnippetList) {
      if (snippet.name.toLowerCase() === oldName.toLowerCase()) {
        // globalService.codeSnippetList.splice(snippet.id, 1, newSnippet);

        snippet.name = newSnippet.name;
        snippet.description = newSnippet.description;
        snippet.language = newSnippet.language;
        snippet.code = newSnippet.code;
        snippet.id = newSnippet.id;
        snippet.tags = newSnippet.tags;
        snippet.templateEngine = newSnippet.templateEngine;
        snippet.voiceName = newSnippet.voiceName;
        snippet.iconURL = newSnippet.iconURL;

        break;
      }
    }

    await globalService.settingManager
      .set(
        'snippets',
        globalService.codeSnippetList as unknown as JSONValue
      )
      .catch((_) => {
        return false;
      });
    return true;
  }

  static async moveSnippet(fromIdx: number, toIdx: number): Promise<boolean> {
    const globalService = CodeSnippetService.getCodeSnippetService();

    if (globalService.codeSnippetList === undefined) {
      return false;
    }

    if (toIdx > fromIdx) {
      toIdx = toIdx - 1;
    }

    if (toIdx === fromIdx) {
      return true;
    }

    const snippetToMove = globalService.codeSnippetList[fromIdx];
    CodeSnippetService.deleteSnippet(fromIdx).then((res: boolean) => {
      if (!res) {
        console.log('Error in moving snippet(delete)');
        return false;
      }
    });
    snippetToMove.id = toIdx;
    CodeSnippetService.addSnippet(snippetToMove).then((res: boolean) => {
      if (!res) {
        console.log('Error in moving snippet(add)');
        return false;
      }
    });

    await globalService.settingManager
      .set(
        'snippets',
        globalService.codeSnippetList as unknown as JSONValue
      )
      .catch((_) => {
        return false;
      });
    return true;
  }

  static async orderSnippets(): Promise<boolean> {
    const globalService = CodeSnippetService.getCodeSnippetService();
    if (globalService.codeSnippetList === undefined) {
      return false;
    }
    return CodeSnippetService.orderSnippets_internal(globalService);
  }
  // order snippets just in case when it gets shared between users
  static async orderSnippets_internal(
    globalService: CodeSnippetService
  ): Promise<boolean> {
    globalService.codeSnippetList.sort((a, b) => a.id - b.id);
    globalService.codeSnippetList.forEach((snippet, i) => (snippet.id = i));

    await globalService.settingManager
      .set(
        'snippets',
        globalService.codeSnippetList as unknown as JSONValue
      )
      .catch((_) => {
        return false;
      });
    return true;
  }
}
