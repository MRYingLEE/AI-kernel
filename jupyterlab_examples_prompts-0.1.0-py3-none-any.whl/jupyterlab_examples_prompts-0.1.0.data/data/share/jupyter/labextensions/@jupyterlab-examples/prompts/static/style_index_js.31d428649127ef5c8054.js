"use strict";
(self["webpackChunk_jupyterlab_examples_prompts"] = self["webpackChunk_jupyterlab_examples_prompts"] || []).push([["style_index_js"],{

/***/ "../node_modules/css-loader/dist/runtime/api.js":
/*!******************************************************!*\
  !*** ../node_modules/css-loader/dist/runtime/api.js ***!
  \******************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ }),

/***/ "../node_modules/css-loader/dist/runtime/getUrl.js":
/*!*********************************************************!*\
  !*** ../node_modules/css-loader/dist/runtime/getUrl.js ***!
  \*********************************************************/
/***/ ((module) => {



module.exports = function (url, options) {
  if (!options) {
    options = {};
  }
  if (!url) {
    return url;
  }
  url = String(url.__esModule ? url.default : url);

  // If url is already wrapped in quotes, remove them
  if (/^['"].*['"]$/.test(url)) {
    url = url.slice(1, -1);
  }
  if (options.hash) {
    url += options.hash;
  }

  // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls
  if (/["'() \t\n]|(%20)/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), "\"");
  }
  return url;
};

/***/ }),

/***/ "../node_modules/css-loader/dist/runtime/sourceMaps.js":
/*!*************************************************************!*\
  !*** ../node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \*************************************************************/
/***/ ((module) => {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!*****************************************************************************!*\
  !*** ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \*****************************************************************************/
/***/ ((module) => {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!*********************************************************************!*\
  !*** ../node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \*********************************************************************/
/***/ ((module) => {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!***********************************************************************!*\
  !*** ../node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \***********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!***********************************************************************************!*\
  !*** ../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!****************************************************************!*\
  !*** ../node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \****************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ }),

/***/ "../node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!**********************************************************************!*\
  !*** ../node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \**********************************************************************/
/***/ ((module) => {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ }),

/***/ "../node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!***************************************************************!*\
  !*** ../node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "../node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "../node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/getUrl.js */ "../node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
// Imports



var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! ./icon/dragtab_jupyter.svg */ "./style/icon/dragtab_jupyter.svg"), __webpack_require__.b);
var ___CSS_LOADER_URL_IMPORT_1___ = new URL(/* asset import */ __webpack_require__(/*! ./icon/jupyter_searcharrowdown.svg */ "./style/icon/jupyter_searcharrowdown.svg"), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_1___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `:root {
    --preview-distance: 0px;
    --preview-max-height: 75px;
    --more-options-top: 0px;
    --more-options-left: 0px;
  }
  
  #code-snippet-extension {
    background-color: var(--jp-layout-color0);
    overflow: auto;
  }
  
  .jp-codeSnippet-fileDialog label {
    margin-bottom: 5px;
  }
  
  /*Code Snippet Container CSS*/
  .jp-codeSnippetsContainer-button,
  .jp-codeSnippetsContainer-button.jp-mod-styled {
    background-color: transparent;
    vertical-align: middle;
    padding: 0;
    padding-right: 8px;
  }
  
  .jp-codeSnippetsContainer-button:hover {
    cursor: pointer;
  }
  
  .jp-codeSnippetsContainer-title {
    align-items: center;
    display: flex;
    justify-content: space-between;
    margin-top: 5px;
    height: 30px;
    color: var(--jp-ui-font-color0);
  }
  
  .jp-codeSnippetsContainer-name {
    font-size: var(--jp-ui-font-size1);
    white-space: nowrap;
    overflow: hidden;
    color: var(--jp-ui-font-color0);
    display: flex;
    align-items: center;
    width: 100%;
  }
  
  .jp-codeSnippetsContainer-name span:nth-child(2) {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    height: 19px;
  }
  
  .jp-codeSnippet-name:hover {
    cursor: pointer;
  }
  
  .jp-codeSnippetsContainer-button {
    background-repeat: no-repeat;
    background-position: center;
    border: none;
    height: 100%;
  }
  
  /* Size of the icons in code snippet */
  .jp-codeSnippetsContainer-action-buttons {
    height: 100%;
    overflow: hidden;
  }
  
  .jp-codeSnippet-item {
    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);
    display: flex;
    margin: 0;
    padding: 0;
    height: fit-content;
    cursor: context-menu;
  }
  
  .jp-codeSnippet-item:hover {
    background-color: var(--jp-layout-color2);
  }
  
  #jp-codeSnippet-rename {
    background-color: var(--jp-layout-color2);
    border: 1px solid var(--jp-layout-color1);
    border-radius: 4px;
    font-size: var(--jp-ui-font-size1);
    box-sizing: border-box;
    margin: 0px;
  }
  
  .jp-codeSnippet-metadata {
    flex-basis: 95%;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;
    overflow: hidden;
  }
  
  .jp-codeSnippet-description p {
    font-size: var(--jp-ui-font-size0);
    line-height: 15px;
    color: var(--jp-layout-color4);
    margin-bottom: 10px;
    width: 90%;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
  }
  
  
  /* Header bar of code snippets */
  .jp-codeSnippetsHeader {
    font-size: var(--jp-ui-font-size1);
    font-weight: 600;
    text-transform: uppercase;
    padding: 8px;
    color: var(--jp-ui-font-color0);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  /* Save Notification CSS */
  .jp-codeSnippet-confirm {
    position: absolute;
    z-index: 10000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    top: 0px;
    left: 0px;
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: var(--jp-dialog-background);
  }
  
  .jp-codeSnippet-Message-content {
    background: var(--jp-layout-color1);
    display: flex;
    align-items: center;
    padding: 0px;
    padding-left: 40px;
    border-top: 7px solid #388e3c;
    width: 250px;
    min-width: 200px;
    min-height: 50px;
    box-sizing: border-box;
    box-shadow: var(--jp-elevation-z20);
    word-wrap: break-word;
    border-radius: var(--jp-border-radius);
    font-size: var(--jp-ui-font-size1);
    color: var(--jp-ui-font-color1);
    margin: auto 6px 30px auto;
    resize: none;
  }
  
  .jp-codeSnippet-Message-content .jp-Dialog-header {
    padding: 0px;
  }
  
  .jp-codeSnippet-Message-content .jp-Dialog-footer {
    padding: 0px;
  }
  
  .jp-codeSnippet-Message-body {
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  
  .jp-codeSnippet-confirm-text {
    width: 183px;
    font-style: normal;
    font-weight: normal;
    font-size: 13px;
    text-align: left;
    padding-left: 10px;
  }
  
  /* Code Snippet Preview CSS */
  .jp-codeSnippet-preview {
    position: absolute;
    z-index: 10000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: 0;
    top: var(--preview-distance);
  }
  
  .jp-codeSnippet-preview.inactive {
    display: none;
  }
  
  .jp-codeSnippet-preview-content {
    background: var(--jp-layout-color1);
    padding: 5px;
    width: 180px;
    height: fit-content;
    max-height: var(--preview-max-height);
    /*height: 106px;*/
    box-sizing: border-box;
    box-shadow: var(--jp-elevation-z2);
    word-wrap: break-word;
    border-radius: var(--jp-border-radius);
    font-size: var(--jp-ui-font-size1);
    color: var(--jp-ui-font-color1);
    margin: 10px 10px 10px 0px;
  }
  
  /* Code Snippet Drag and Drop CSS */
  .jp-codeSnippet-drag-hover-selected {
    background-image: url(${___CSS_LOADER_URL_REPLACEMENT_0___});
    margin-right: -2px;
    background-color: var(--jp-layout-color2);
    background-position: center;
    background-repeat: no-repeat;
  }
  
  .jp-codeSnippet-drag-image {
    border: var(--jp-border-width) solid var(--jp-cell-editor-border-color);
    background: var(--jp-cell-editor-background);
    width: var(--jp-private-notebook-dragImage-width);
    height: var(--jp-private-notebook-dragImage-height);
  }
  
  .jp-codeSnippet-item.jp-codeSnippet-dropTarget {
    border-top: 2px solid var(--jp-private-notebook-selected-color);
  }
  
  .jp-codeSnippet-drag-hover {
    flex-basis: 5%;
    min-width: 20px;
    padding-right: 5px;
    margin-right: 5px;
    cursor: move;
  }
  
  /* Code Snippet Editor CSS */
  .jp-codeSnippet-editor-title {
    margin-left: 2%;
    margin-top: 2%;
    margin-bottom: 20px;
    color: var(--jp-ui-font-color0);
    font-size: 25px;
  }
  
  .jp-codeSnippet-editor-label {
    margin-left: 2%;
    margin-bottom: 5px;
    font-size: var(--jp-ui-font-size1);
    color: var(--jp-ui-font-color0);
  }
  /* 
  .flexAlignLeft {
    display: flex;
    align-items: left;
  } */
  
  .flexAlignColumn {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
  }
  
  /* .flexAlignCenter {
    display: flex;
    align-items: center;
  }
  */
  
  .flexAlignRight {
    display: flex;
    justify-content: flex-end;
  } 
  
  .jp-codeSnippet-editor-name,
  .jp-codeSnippet-editor-description {
    display: block;
    margin-left: 2%;
    border-top: transparent;
    border-left: transparent;
    border-right: transparent;
    width: 94%;
    height: 32px;
    font-size: var(--jp-ui-font-size1);
    border-radius: 2px;
    background: var(--jp-input-background);
    box-sizing: border-box;
    border: var(--jp-border-width) solid var(--jp-border-color1);
    padding-left: 7px;
    padding-right: 7px;
    color: var(--jp-ui-font-color0);
    outline: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    margin-top: 5px;
    margin-bottom: 15px;
  }
  
  .jp-codeSnippet-editor-iconurl,
  .jp-codeSnippet-editor-voicename{
    display: block;
    margin-bottom: 20px;
    margin-left: 2%;
    width: 80%;
    height: 32px;
    font-size: var(--jp-ui-font-size1);
    border-radius: 2px;
    -webkit-appearance: none; /* chrome and safari */
    -moz-appearance: none; /* Mozilla */
    -ms-appearance: none; /* Internet explorer */
    appearance: none;
    color: var(--jp-ui-font-color0);
    outline: none;
    background: var(--jp-input-background);
    box-sizing: border-box;
    border: var(--jp-border-width) solid var(--jp-border-color1);
    padding-left: 7px;
    padding-right: 7px;
    background-image: url(${___CSS_LOADER_URL_REPLACEMENT_1___});
    background-repeat: no-repeat;
    background-position: 95% center;
    margin-top: 5px;
  }
  
  .jp-codeSnippet-editor-language {
    display: block;
    margin-bottom: 20px;
    margin-left: 2%;
    width: 176px;
    height: 32px;
    font-size: var(--jp-ui-font-size1);
    border-radius: 2px;
    -webkit-appearance: none; /* chrome and safari */
    -moz-appearance: none; /* Mozilla */
    -ms-appearance: none; /* Internet explorer */
    appearance: none;
    color: var(--jp-ui-font-color0);
    outline: none;
    background: var(--jp-input-background);
    box-sizing: border-box;
    border: var(--jp-border-width) solid var(--jp-border-color1);
    padding-left: 7px;
    padding-right: 7px;
    background-image: url(${___CSS_LOADER_URL_REPLACEMENT_1___});
    background-repeat: no-repeat;
    background-position: 95% center;
    margin-top: 5px;
  }
  
  .jp-codeSnippet-editor-voicename,
  .jp-codeSnippet-editor-language:hover {
    background-image: none;
  }
  
  .jp-codeSnippet-editor-templateengine {
    display: block;
    margin-bottom: 20px;
    margin-left: 2%;
    width: 176px;
    height: 32px;
    font-size: var(--jp-ui-font-size1);
    border-radius: 2px;
    -webkit-appearance: none; /* chrome and safari */
    -moz-appearance: none; /* Mozilla */
    -ms-appearance: none; /* Internet explorer */
    appearance: none;
    color: var(--jp-ui-font-color0);
    outline: none;
    background: var(--jp-input-background);
    box-sizing: border-box;
    border: var(--jp-border-width) solid var(--jp-border-color1);
    padding-left: 7px;
    padding-right: 7px;
    background-image: url(${___CSS_LOADER_URL_REPLACEMENT_1___});
    background-repeat: no-repeat;
    background-position: 95% center;
    margin-top: 5px;
  }
  
  .jp-codeSnippet-editor-templateengine :hover {
    background-image: none;
  }
  
  .jp-codeSnippet-editor-tagList {
    list-style: none;
    margin-left: 2%;
    margin-bottom: 8px;
    margin-top: -8px;
  }
  
  .jp-codeSnippet-editor-tag {
    margin-left: 3px;
    margin-right: 3px;
  }
  
  .jp-codeSnippet-editor-tag button {
    cursor: pointer;
    background: none;
    border: none;
    color: var(--jp-ui-font-color2);
    padding: 0;
    font-size: var(--jp-ui-font-size1);
  }
  
  .jp-codeSnippet-editor-tag input {
    border: none;
    background: transparent;
  }
  
  .jp-codeSnippet-editor-tag.applied-tag button {
    color: var(--jp-ui-font-color1);
  }
  
  .jp-codeSnippet-editor-tag.unapplied-tag button {
    color: var(--jp-ui-font-color2);
  }
  
  .jp-codeSnippet-editor-tag.tag.unapplied-tag input {
    border: none;
    background: transparent;
  }
  
  .jp-codeSnippet-editor-active {
    border: 1px solid var(--jp-cell-editor-active-border-color);
    background-color: var(--jp-input-active-background);
  }
  .jp-codeSnippetInputArea {
    display: flex;
    flex-direction: column;
    height: 100%;
    width: 98.5%;
    padding-left: 12px;
  }
  
  .jp-codeSnippetInputArea-editor {
    overflow: auto;
    margin-left: 2%;
    margin-right: 3%;
    margin-top: 5px;
  }
  
  .jp-codeSnippetInput-editor {
    border: var(--jp-border-width) solid var(--jp-cell-editor-border-color);
    border-radius: 0px;
    background: var(--jp-cell-editor-background);
  }
  
  .jp-codeSnippetInput-editor.active {
    border: var(--jp-border-width) solid var(--jp-cell-editor-active-border-color);
    box-shadow: var(--jp-input-box-shadow);
    background-color: var(--jp-cell-editor-active-background);
  }
  
  .jp-codeSnippetInput-editor .CodeMirror.cm-s-jupyter {
    background: transparent;
  }
  
  .jp-codeSnippetInputArea .saveBtn {
    width: 10%;
    background: var(--jp-brand-color1);
    color: var(--jp-ui-inverse-font-color0);
    align-self: flex-end;
    margin-top: 12px;
    margin-right: 3%;
    margin-bottom: 12px;
  }
  
  .jp-codeSnippetInputArea .voiceBtn {
    width: 10%;
    background: var(--jp-brand-color1);
    color: var(--jp-ui-inverse-font-color0);
    align-self: flex-end;
    margin-top: 12px;
    margin-right: 3%;
    margin-bottom: 12px;
  }
  
  /* code snippet create button */
  .jp-importSnippetBtn,
  .jp-exportAllSnippetBtn,
  .jp-refreshSnippetBtn,
  .jp-createSnippetBtn {
    cursor: pointer;
    border: none; 
    background: none;
    padding: 0px;
  }
  
  /* @import url('~@jupyterlab/codeeditor/style/index.css'); */
  
  /* Code Snippet Filter CSS */
  .jp-codeSnippet-searchbar {
    margin: 0px 8px;
  }
  
  .jp-codeSnippet-filterTools {
    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);
  }
  
  mark.jp-codeSnippet-search-bolding {
    background-color: transparent;
    font-weight: bold;
    color: var(--jp-ui-font-color0);
  }
  
  .jp-codeSnippet-filter {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin: 10px 10px 0 10px;
  }
  
  .jp-codeSnippet-filter .jp-codeSnippet-filter-btn {
    align-self: flex-end;
    padding: 0px;
    padding-bottom: 10px;
    border: none;
    background: none;
    cursor: pointer;
    color: var(--jp-brand-color2);
  }
  
  .jp-codeSnippet-filter-arrow-up.idle,
  .jp-codeSnippet-filter-option.idle {
    display: none;
  }
  
  .jp-codeSnippet-filter-arrow-up {
    position: absolute;
    margin-top: 20px;
    border: var(--jp-border-width) solid var(--jp-border-color2);
    border-width: 0 var(--jp-border-width) var(--jp-border-width) 0;
    padding: 4px;
    margin-right: 38px;
    align-self: flex-end;
    -webkit-transform: rotate(-135deg);
    transform: rotate(-135deg);
    background-color: var(--jp-layout-color0);
  }
  
  .jp-codeSnippet-filter-option {
    border: var(--jp-border-width) solid var(--jp-border-color2);
    height: 140px;
    width: 100%;
    margin-bottom: 10px;
    overflow: auto;
  }
  
  .jp-codeSnippet-filter-title {
    text-transform: uppercase;
    color: var(--jp-ui-font-color2);
    font-size: var(--jp-ui-font-size1);
    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);
    margin: 10px 10px;
    padding-bottom: 5px;
  }
  
  .jp-codeSnippet-filter-tags {
    margin: 0px 8px;
  }
  
  .jp-codeSnippet-filter-tag {
    margin-left: 3px;
    margin-right: 3px;
  }
  
  .jp-codeSnippet-filter-tag button {
    cursor: pointer;
    background: none;
    border: none;
    color: var(--jp-ui-font-color2);
    padding: 0;
    font-size: var(--jp-ui-font-size1);
  }
  
  .jp-codeSnippet-tools {
    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);
  }
  
  /* Code Snippet Tags in InputDialog */
  .jp-codeSnippet-inputTagList {
    list-style: none;
  }
  
  .jp-codeSnippet-inputTag {
    margin-left: 8px;
    margin-right: 8px;
  }
  
  .jp-codeSnippet-inputTag button {
    cursor: pointer;
    background: none;
    border: none;
    color: var(--jp-ui-font-color2);
    padding: 0;
    font-size: var(--jp-ui-font-size1);
  }
  
  .jp-codeSnippet-inputTag input {
    font-size: var(--jp-ui-font-size1);
    background: none;
    border: none;
    color: var(--jp-ui-font-color2);
    padding: 0;
    font-size: var(--jp-ui-font-size1);
    width: 50px;
  }
  
  .jp-codeSnippet-tags {
    margin-top: 8px;
  }
  
  /* .jp-codeSnippet-tag,
  .jp-codeSnippet-inputTag,
  .jp-codeSnippet-filter-tag {
    height: 5px;
  } */
  
  /* USER Input Form Style
  .jp-codeSnippet-form {
    position: absolute;
    z-index: 10000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    top: 0px;
    left: 0px;
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: var(--jp-dialog-background);
  } */
  
  /* .jp-codesnippet-editor-name:required {
      border-color: #808080;
      border-width: 3px;
    } */
  
  .jp-codeSnippet-dialog-name-input.touched:invalid,
  .jp-codeSnippet-dialog-desc-input.touched:invalid,
  .jp-codeSnippet-dialog-lang-input.touched:invalid,
  .jp-codeSnippet-editor-name.touched:invalid,
  .jp-codeSnippet-editor-description.touched:invalid,
  .jp-codeSnippet-editor-language.touched:invalid {
    border: var(--jp-border-width) solid var(--jp-error-color1);
  }
  
  .jp-codeSnippet-editor-templateengine 
  .jp-codeSnippet-editor-voicename,
  .jp-codeSnippet-editor-language.touched:invalid {
    border: var(--jp-border-width) solid var(--jp-error-color1);
  }
  
  .jp-codeSnippet-dialog-name-input.jp-mod-styled,
  .jp-codeSnippet-dialog-desc-input.jp-mod-styled,
  .jp-codeSnippet-dialog-lang-input.jp-mod-styled {
    margin-bottom: 10px;
    font-size: var(--jp-ui-font-size1);
  }
  
  .jp-codeSnippet-inputName-validity,
  .jp-codeSnippet-inputDesc-validity {
    font-size: var(--jp-ui-font-size0);
    color: var(--jp-ui-font-color1);
    margin: 5px;
    margin-bottom: 8px;
  }
  
  .jp-codeSnippet-editor-metadata .jp-codeSnippet-inputName-validity,
  .jp-codeSnippet-editor-metadata .jp-codeSnippet-inputDesc-validity {
    margin-bottom: 20px;
    margin-top: 5px;
    margin-left: 3%;
  }
  
  /* 3 Dots Dropdown On Code Snippet */
  .jp-codeSnippet-options {
    position: absolute;
    z-index: 10000;
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: 0;
    background-color: transparent;
  }
  
  .jp-codeSnippet-options.inactive {
    display: none;
  }
  
  .jp-codeSnippet-more-options-content {
    width: 183px;
    font-style: normal;
    font-weight: normal;
    font-size: 13px;
    text-align: left;
  }
  
  .jp-codeSnippet-options-content {
    background: var(--jp-layout-color1);
    padding: 10px;
    border: 1px solid var(--jp-border-color0);
    width: 180px;
    box-sizing: border-box;
    box-shadow: var(--jp-elevation-z1);
    word-wrap: break-word;
    border-radius: var(--jp-border-radius);
    font-size: var(--jp-ui-font-size0);
    color: var(--jp-ui-font-color1);
    position: absolute;
    top: var(--more-options-top);
    left: var(--more-options-left);
  }
  
  .jp-codeSnippet-options-body {
    display: flex;
    align-items: center;
  }
  
  .jp-codeSnippet-more-options-copy {
    padding-bottom: 5px;
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-copy:hover {
    background-color: var(--jp-layout-color2);
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-insert {
    padding-bottom: 5px;
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-insert:hover {
    background-color: var(--jp-layout-color2);
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-edit {
    padding-bottom: 5px;
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-edit:hover {
    background-color: var(--jp-layout-color2);
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-delete {
    color: var(--jp-error-color0);
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-delete:hover {
    background-color: var(--jp-layout-color2);
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-export {
    color: var(--jp-brand-color0);
    padding-bottom: 5px;
    cursor: pointer;
  }
  
  .jp-codeSnippet-more-options-export:hover {
    background-color: var(--jp-layout-color2);
    cursor: pointer;
  }
  
  .jp-dropdown-delete-button {
    border: none;
  }
  
  .jp-dropdown-cancel-button {
    outline: 1px solid var(--jp-brand-color1);
    outline-offset: 4px;
  }`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;IACI,uBAAuB;IACvB,0BAA0B;IAC1B,uBAAuB;IACvB,wBAAwB;EAC1B;;EAEA;IACE,yCAAyC;IACzC,cAAc;EAChB;;EAEA;IACE,kBAAkB;EACpB;;EAEA,6BAA6B;EAC7B;;IAEE,6BAA6B;IAC7B,sBAAsB;IACtB,UAAU;IACV,kBAAkB;EACpB;;EAEA;IACE,eAAe;EACjB;;EAEA;IACE,mBAAmB;IACnB,aAAa;IACb,8BAA8B;IAC9B,eAAe;IACf,YAAY;IACZ,+BAA+B;EACjC;;EAEA;IACE,kCAAkC;IAClC,mBAAmB;IACnB,gBAAgB;IAChB,+BAA+B;IAC/B,aAAa;IACb,mBAAmB;IACnB,WAAW;EACb;;EAEA;IACE,mBAAmB;IACnB,gBAAgB;IAChB,uBAAuB;IACvB,YAAY;EACd;;EAEA;IACE,eAAe;EACjB;;EAEA;IACE,4BAA4B;IAC5B,2BAA2B;IAC3B,YAAY;IACZ,YAAY;EACd;;EAEA,sCAAsC;EACtC;IACE,YAAY;IACZ,gBAAgB;EAClB;;EAEA;IACE,mEAAmE;IACnE,aAAa;IACb,SAAS;IACT,UAAU;IACV,mBAAmB;IACnB,oBAAoB;EACtB;;EAEA;IACE,yCAAyC;EAC3C;;EAEA;IACE,yCAAyC;IACzC,yCAAyC;IACzC,kBAAkB;IAClB,kCAAkC;IAClC,sBAAsB;IACtB,WAAW;EACb;;EAEA;IACE,eAAe;IACf,WAAW;IACX,aAAa;IACb,sBAAsB;IACtB,6BAA6B;IAC7B,gBAAgB;EAClB;;EAEA;IACE,kCAAkC;IAClC,iBAAiB;IACjB,8BAA8B;IAC9B,mBAAmB;IACnB,UAAU;IACV,oBAAoB;IACpB,4BAA4B;IAC5B,qBAAqB;IACrB,gBAAgB;EAClB;;;EAGA,gCAAgC;EAChC;IACE,kCAAkC;IAClC,gBAAgB;IAChB,yBAAyB;IACzB,YAAY;IACZ,+BAA+B;IAC/B,aAAa;IACb,8BAA8B;IAC9B,mBAAmB;EACrB;;EAEA,0BAA0B;EAC1B;IACE,kBAAkB;IAClB,cAAc;IACd,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,uBAAuB;IACvB,QAAQ;IACR,SAAS;IACT,SAAS;IACT,UAAU;IACV,WAAW;IACX,YAAY;IACZ,uCAAuC;EACzC;;EAEA;IACE,mCAAmC;IACnC,aAAa;IACb,mBAAmB;IACnB,YAAY;IACZ,kBAAkB;IAClB,6BAA6B;IAC7B,YAAY;IACZ,gBAAgB;IAChB,gBAAgB;IAChB,sBAAsB;IACtB,mCAAmC;IACnC,qBAAqB;IACrB,sCAAsC;IACtC,kCAAkC;IAClC,+BAA+B;IAC/B,0BAA0B;IAC1B,YAAY;EACd;;EAEA;IACE,YAAY;EACd;;EAEA;IACE,YAAY;EACd;;EAEA;IACE,aAAa;IACb,mBAAmB;IACnB,mBAAmB;EACrB;;EAEA;IACE,YAAY;IACZ,kBAAkB;IAClB,mBAAmB;IACnB,eAAe;IACf,gBAAgB;IAChB,kBAAkB;EACpB;;EAEA,6BAA6B;EAC7B;IACE,kBAAkB;IAClB,cAAc;IACd,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,uBAAuB;IACvB,SAAS;IACT,4BAA4B;EAC9B;;EAEA;IACE,aAAa;EACf;;EAEA;IACE,mCAAmC;IACnC,YAAY;IACZ,YAAY;IACZ,mBAAmB;IACnB,qCAAqC;IACrC,iBAAiB;IACjB,sBAAsB;IACtB,kCAAkC;IAClC,qBAAqB;IACrB,sCAAsC;IACtC,kCAAkC;IAClC,+BAA+B;IAC/B,0BAA0B;EAC5B;;EAEA,mCAAmC;EACnC;IACE,yDAAiD;IACjD,kBAAkB;IAClB,yCAAyC;IACzC,2BAA2B;IAC3B,4BAA4B;EAC9B;;EAEA;IACE,uEAAuE;IACvE,4CAA4C;IAC5C,iDAAiD;IACjD,mDAAmD;EACrD;;EAEA;IACE,+DAA+D;EACjE;;EAEA;IACE,cAAc;IACd,eAAe;IACf,kBAAkB;IAClB,iBAAiB;IACjB,YAAY;EACd;;EAEA,4BAA4B;EAC5B;IACE,eAAe;IACf,cAAc;IACd,mBAAmB;IACnB,+BAA+B;IAC/B,eAAe;EACjB;;EAEA;IACE,eAAe;IACf,kBAAkB;IAClB,kCAAkC;IAClC,+BAA+B;EACjC;EACA;;;;KAIG;;EAEH;IACE,aAAa;IACb,sBAAsB;IACtB,uBAAuB;EACzB;;EAEA;;;;GAIC;;EAED;IACE,aAAa;IACb,yBAAyB;EAC3B;;EAEA;;IAEE,cAAc;IACd,eAAe;IACf,uBAAuB;IACvB,wBAAwB;IACxB,yBAAyB;IACzB,UAAU;IACV,YAAY;IACZ,kCAAkC;IAClC,kBAAkB;IAClB,sCAAsC;IACtC,sBAAsB;IACtB,4DAA4D;IAC5D,iBAAiB;IACjB,kBAAkB;IAClB,+BAA+B;IAC/B,aAAa;IACb,wBAAwB;IACxB,qBAAqB;IACrB,gBAAgB;IAChB,eAAe;IACf,mBAAmB;EACrB;;EAEA;;IAEE,cAAc;IACd,mBAAmB;IACnB,eAAe;IACf,UAAU;IACV,YAAY;IACZ,kCAAkC;IAClC,kBAAkB;IAClB,wBAAwB,EAAE,sBAAsB;IAChD,qBAAqB,EAAE,YAAY;IACnC,oBAAoB,EAAE,sBAAsB;IAC5C,gBAAgB;IAChB,+BAA+B;IAC/B,aAAa;IACb,sCAAsC;IACtC,sBAAsB;IACtB,4DAA4D;IAC5D,iBAAiB;IACjB,kBAAkB;IAClB,yDAAyD;IACzD,4BAA4B;IAC5B,+BAA+B;IAC/B,eAAe;EACjB;;EAEA;IACE,cAAc;IACd,mBAAmB;IACnB,eAAe;IACf,YAAY;IACZ,YAAY;IACZ,kCAAkC;IAClC,kBAAkB;IAClB,wBAAwB,EAAE,sBAAsB;IAChD,qBAAqB,EAAE,YAAY;IACnC,oBAAoB,EAAE,sBAAsB;IAC5C,gBAAgB;IAChB,+BAA+B;IAC/B,aAAa;IACb,sCAAsC;IACtC,sBAAsB;IACtB,4DAA4D;IAC5D,iBAAiB;IACjB,kBAAkB;IAClB,yDAAyD;IACzD,4BAA4B;IAC5B,+BAA+B;IAC/B,eAAe;EACjB;;EAEA;;IAEE,sBAAsB;EACxB;;EAEA;IACE,cAAc;IACd,mBAAmB;IACnB,eAAe;IACf,YAAY;IACZ,YAAY;IACZ,kCAAkC;IAClC,kBAAkB;IAClB,wBAAwB,EAAE,sBAAsB;IAChD,qBAAqB,EAAE,YAAY;IACnC,oBAAoB,EAAE,sBAAsB;IAC5C,gBAAgB;IAChB,+BAA+B;IAC/B,aAAa;IACb,sCAAsC;IACtC,sBAAsB;IACtB,4DAA4D;IAC5D,iBAAiB;IACjB,kBAAkB;IAClB,yDAAyD;IACzD,4BAA4B;IAC5B,+BAA+B;IAC/B,eAAe;EACjB;;EAEA;IACE,sBAAsB;EACxB;;EAEA;IACE,gBAAgB;IAChB,eAAe;IACf,kBAAkB;IAClB,gBAAgB;EAClB;;EAEA;IACE,gBAAgB;IAChB,iBAAiB;EACnB;;EAEA;IACE,eAAe;IACf,gBAAgB;IAChB,YAAY;IACZ,+BAA+B;IAC/B,UAAU;IACV,kCAAkC;EACpC;;EAEA;IACE,YAAY;IACZ,uBAAuB;EACzB;;EAEA;IACE,+BAA+B;EACjC;;EAEA;IACE,+BAA+B;EACjC;;EAEA;IACE,YAAY;IACZ,uBAAuB;EACzB;;EAEA;IACE,2DAA2D;IAC3D,mDAAmD;EACrD;EACA;IACE,aAAa;IACb,sBAAsB;IACtB,YAAY;IACZ,YAAY;IACZ,kBAAkB;EACpB;;EAEA;IACE,cAAc;IACd,eAAe;IACf,gBAAgB;IAChB,eAAe;EACjB;;EAEA;IACE,uEAAuE;IACvE,kBAAkB;IAClB,4CAA4C;EAC9C;;EAEA;IACE,8EAA8E;IAC9E,sCAAsC;IACtC,yDAAyD;EAC3D;;EAEA;IACE,uBAAuB;EACzB;;EAEA;IACE,UAAU;IACV,kCAAkC;IAClC,uCAAuC;IACvC,oBAAoB;IACpB,gBAAgB;IAChB,gBAAgB;IAChB,mBAAmB;EACrB;;EAEA;IACE,UAAU;IACV,kCAAkC;IAClC,uCAAuC;IACvC,oBAAoB;IACpB,gBAAgB;IAChB,gBAAgB;IAChB,mBAAmB;EACrB;;EAEA,+BAA+B;EAC/B;;;;IAIE,eAAe;IACf,YAAY;IACZ,gBAAgB;IAChB,YAAY;EACd;;EAEA,4DAA4D;;EAE5D,4BAA4B;EAC5B;IACE,eAAe;EACjB;;EAEA;IACE,mEAAmE;EACrE;;EAEA;IACE,6BAA6B;IAC7B,iBAAiB;IACjB,+BAA+B;EACjC;;EAEA;IACE,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,wBAAwB;EAC1B;;EAEA;IACE,oBAAoB;IACpB,YAAY;IACZ,oBAAoB;IACpB,YAAY;IACZ,gBAAgB;IAChB,eAAe;IACf,6BAA6B;EAC/B;;EAEA;;IAEE,aAAa;EACf;;EAEA;IACE,kBAAkB;IAClB,gBAAgB;IAChB,4DAA4D;IAC5D,+DAA+D;IAC/D,YAAY;IACZ,kBAAkB;IAClB,oBAAoB;IACpB,kCAAkC;IAClC,0BAA0B;IAC1B,yCAAyC;EAC3C;;EAEA;IACE,4DAA4D;IAC5D,aAAa;IACb,WAAW;IACX,mBAAmB;IACnB,cAAc;EAChB;;EAEA;IACE,yBAAyB;IACzB,+BAA+B;IAC/B,kCAAkC;IAClC,mEAAmE;IACnE,iBAAiB;IACjB,mBAAmB;EACrB;;EAEA;IACE,eAAe;EACjB;;EAEA;IACE,gBAAgB;IAChB,iBAAiB;EACnB;;EAEA;IACE,eAAe;IACf,gBAAgB;IAChB,YAAY;IACZ,+BAA+B;IAC/B,UAAU;IACV,kCAAkC;EACpC;;EAEA;IACE,mEAAmE;EACrE;;EAEA,qCAAqC;EACrC;IACE,gBAAgB;EAClB;;EAEA;IACE,gBAAgB;IAChB,iBAAiB;EACnB;;EAEA;IACE,eAAe;IACf,gBAAgB;IAChB,YAAY;IACZ,+BAA+B;IAC/B,UAAU;IACV,kCAAkC;EACpC;;EAEA;IACE,kCAAkC;IAClC,gBAAgB;IAChB,YAAY;IACZ,+BAA+B;IAC/B,UAAU;IACV,kCAAkC;IAClC,WAAW;EACb;;EAEA;IACE,eAAe;EACjB;;EAEA;;;;KAIG;;EAEH;;;;;;;;;;;;;;;KAeG;;EAEH;;;OAGK;;EAEL;;;;;;IAME,2DAA2D;EAC7D;;EAEA;;;IAGE,2DAA2D;EAC7D;;EAEA;;;IAGE,mBAAmB;IACnB,kCAAkC;EACpC;;EAEA;;IAEE,kCAAkC;IAClC,+BAA+B;IAC/B,WAAW;IACX,kBAAkB;EACpB;;EAEA;;IAEE,mBAAmB;IACnB,eAAe;IACf,eAAe;EACjB;;EAEA,oCAAoC;EACpC;IACE,kBAAkB;IAClB,cAAc;IACd,YAAY;IACZ,WAAW;IACX,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,uBAAuB;IACvB,SAAS;IACT,6BAA6B;EAC/B;;EAEA;IACE,aAAa;EACf;;EAEA;IACE,YAAY;IACZ,kBAAkB;IAClB,mBAAmB;IACnB,eAAe;IACf,gBAAgB;EAClB;;EAEA;IACE,mCAAmC;IACnC,aAAa;IACb,yCAAyC;IACzC,YAAY;IACZ,sBAAsB;IACtB,kCAAkC;IAClC,qBAAqB;IACrB,sCAAsC;IACtC,kCAAkC;IAClC,+BAA+B;IAC/B,kBAAkB;IAClB,4BAA4B;IAC5B,8BAA8B;EAChC;;EAEA;IACE,aAAa;IACb,mBAAmB;EACrB;;EAEA;IACE,mBAAmB;IACnB,eAAe;EACjB;;EAEA;IACE,yCAAyC;IACzC,eAAe;EACjB;;EAEA;IACE,mBAAmB;IACnB,eAAe;EACjB;;EAEA;IACE,yCAAyC;IACzC,eAAe;EACjB;;EAEA;IACE,mBAAmB;IACnB,eAAe;EACjB;;EAEA;IACE,yCAAyC;IACzC,eAAe;EACjB;;EAEA;IACE,6BAA6B;IAC7B,eAAe;EACjB;;EAEA;IACE,yCAAyC;IACzC,eAAe;EACjB;;EAEA;IACE,6BAA6B;IAC7B,mBAAmB;IACnB,eAAe;EACjB;;EAEA;IACE,yCAAyC;IACzC,eAAe;EACjB;;EAEA;IACE,YAAY;EACd;;EAEA;IACE,yCAAyC;IACzC,mBAAmB;EACrB","sourcesContent":[":root {\n    --preview-distance: 0px;\n    --preview-max-height: 75px;\n    --more-options-top: 0px;\n    --more-options-left: 0px;\n  }\n  \n  #code-snippet-extension {\n    background-color: var(--jp-layout-color0);\n    overflow: auto;\n  }\n  \n  .jp-codeSnippet-fileDialog label {\n    margin-bottom: 5px;\n  }\n  \n  /*Code Snippet Container CSS*/\n  .jp-codeSnippetsContainer-button,\n  .jp-codeSnippetsContainer-button.jp-mod-styled {\n    background-color: transparent;\n    vertical-align: middle;\n    padding: 0;\n    padding-right: 8px;\n  }\n  \n  .jp-codeSnippetsContainer-button:hover {\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippetsContainer-title {\n    align-items: center;\n    display: flex;\n    justify-content: space-between;\n    margin-top: 5px;\n    height: 30px;\n    color: var(--jp-ui-font-color0);\n  }\n  \n  .jp-codeSnippetsContainer-name {\n    font-size: var(--jp-ui-font-size1);\n    white-space: nowrap;\n    overflow: hidden;\n    color: var(--jp-ui-font-color0);\n    display: flex;\n    align-items: center;\n    width: 100%;\n  }\n  \n  .jp-codeSnippetsContainer-name span:nth-child(2) {\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    height: 19px;\n  }\n  \n  .jp-codeSnippet-name:hover {\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippetsContainer-button {\n    background-repeat: no-repeat;\n    background-position: center;\n    border: none;\n    height: 100%;\n  }\n  \n  /* Size of the icons in code snippet */\n  .jp-codeSnippetsContainer-action-buttons {\n    height: 100%;\n    overflow: hidden;\n  }\n  \n  .jp-codeSnippet-item {\n    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);\n    display: flex;\n    margin: 0;\n    padding: 0;\n    height: fit-content;\n    cursor: context-menu;\n  }\n  \n  .jp-codeSnippet-item:hover {\n    background-color: var(--jp-layout-color2);\n  }\n  \n  #jp-codeSnippet-rename {\n    background-color: var(--jp-layout-color2);\n    border: 1px solid var(--jp-layout-color1);\n    border-radius: 4px;\n    font-size: var(--jp-ui-font-size1);\n    box-sizing: border-box;\n    margin: 0px;\n  }\n  \n  .jp-codeSnippet-metadata {\n    flex-basis: 95%;\n    width: 100%;\n    display: flex;\n    flex-direction: column;\n    justify-content: space-evenly;\n    overflow: hidden;\n  }\n  \n  .jp-codeSnippet-description p {\n    font-size: var(--jp-ui-font-size0);\n    line-height: 15px;\n    color: var(--jp-layout-color4);\n    margin-bottom: 10px;\n    width: 90%;\n    display: -webkit-box;\n    -webkit-box-orient: vertical;\n    -webkit-line-clamp: 2;\n    overflow: hidden;\n  }\n  \n  \n  /* Header bar of code snippets */\n  .jp-codeSnippetsHeader {\n    font-size: var(--jp-ui-font-size1);\n    font-weight: 600;\n    text-transform: uppercase;\n    padding: 8px;\n    color: var(--jp-ui-font-color0);\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n  }\n  \n  /* Save Notification CSS */\n  .jp-codeSnippet-confirm {\n    position: absolute;\n    z-index: 10000;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    top: 0px;\n    left: 0px;\n    margin: 0;\n    padding: 0;\n    width: 100%;\n    height: 100%;\n    background: var(--jp-dialog-background);\n  }\n  \n  .jp-codeSnippet-Message-content {\n    background: var(--jp-layout-color1);\n    display: flex;\n    align-items: center;\n    padding: 0px;\n    padding-left: 40px;\n    border-top: 7px solid #388e3c;\n    width: 250px;\n    min-width: 200px;\n    min-height: 50px;\n    box-sizing: border-box;\n    box-shadow: var(--jp-elevation-z20);\n    word-wrap: break-word;\n    border-radius: var(--jp-border-radius);\n    font-size: var(--jp-ui-font-size1);\n    color: var(--jp-ui-font-color1);\n    margin: auto 6px 30px auto;\n    resize: none;\n  }\n  \n  .jp-codeSnippet-Message-content .jp-Dialog-header {\n    padding: 0px;\n  }\n  \n  .jp-codeSnippet-Message-content .jp-Dialog-footer {\n    padding: 0px;\n  }\n  \n  .jp-codeSnippet-Message-body {\n    display: flex;\n    flex-direction: row;\n    align-items: center;\n  }\n  \n  .jp-codeSnippet-confirm-text {\n    width: 183px;\n    font-style: normal;\n    font-weight: normal;\n    font-size: 13px;\n    text-align: left;\n    padding-left: 10px;\n  }\n  \n  /* Code Snippet Preview CSS */\n  .jp-codeSnippet-preview {\n    position: absolute;\n    z-index: 10000;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    margin: 0;\n    top: var(--preview-distance);\n  }\n  \n  .jp-codeSnippet-preview.inactive {\n    display: none;\n  }\n  \n  .jp-codeSnippet-preview-content {\n    background: var(--jp-layout-color1);\n    padding: 5px;\n    width: 180px;\n    height: fit-content;\n    max-height: var(--preview-max-height);\n    /*height: 106px;*/\n    box-sizing: border-box;\n    box-shadow: var(--jp-elevation-z2);\n    word-wrap: break-word;\n    border-radius: var(--jp-border-radius);\n    font-size: var(--jp-ui-font-size1);\n    color: var(--jp-ui-font-color1);\n    margin: 10px 10px 10px 0px;\n  }\n  \n  /* Code Snippet Drag and Drop CSS */\n  .jp-codeSnippet-drag-hover-selected {\n    background-image: url(./icon/dragtab_jupyter.svg);\n    margin-right: -2px;\n    background-color: var(--jp-layout-color2);\n    background-position: center;\n    background-repeat: no-repeat;\n  }\n  \n  .jp-codeSnippet-drag-image {\n    border: var(--jp-border-width) solid var(--jp-cell-editor-border-color);\n    background: var(--jp-cell-editor-background);\n    width: var(--jp-private-notebook-dragImage-width);\n    height: var(--jp-private-notebook-dragImage-height);\n  }\n  \n  .jp-codeSnippet-item.jp-codeSnippet-dropTarget {\n    border-top: 2px solid var(--jp-private-notebook-selected-color);\n  }\n  \n  .jp-codeSnippet-drag-hover {\n    flex-basis: 5%;\n    min-width: 20px;\n    padding-right: 5px;\n    margin-right: 5px;\n    cursor: move;\n  }\n  \n  /* Code Snippet Editor CSS */\n  .jp-codeSnippet-editor-title {\n    margin-left: 2%;\n    margin-top: 2%;\n    margin-bottom: 20px;\n    color: var(--jp-ui-font-color0);\n    font-size: 25px;\n  }\n  \n  .jp-codeSnippet-editor-label {\n    margin-left: 2%;\n    margin-bottom: 5px;\n    font-size: var(--jp-ui-font-size1);\n    color: var(--jp-ui-font-color0);\n  }\n  /* \n  .flexAlignLeft {\n    display: flex;\n    align-items: left;\n  } */\n  \n  .flexAlignColumn {\n    display: flex;\n    flex-direction: column;\n    align-items: flex-start;\n  }\n  \n  /* .flexAlignCenter {\n    display: flex;\n    align-items: center;\n  }\n  */\n  \n  .flexAlignRight {\n    display: flex;\n    justify-content: flex-end;\n  } \n  \n  .jp-codeSnippet-editor-name,\n  .jp-codeSnippet-editor-description {\n    display: block;\n    margin-left: 2%;\n    border-top: transparent;\n    border-left: transparent;\n    border-right: transparent;\n    width: 94%;\n    height: 32px;\n    font-size: var(--jp-ui-font-size1);\n    border-radius: 2px;\n    background: var(--jp-input-background);\n    box-sizing: border-box;\n    border: var(--jp-border-width) solid var(--jp-border-color1);\n    padding-left: 7px;\n    padding-right: 7px;\n    color: var(--jp-ui-font-color0);\n    outline: none;\n    -webkit-appearance: none;\n    -moz-appearance: none;\n    appearance: none;\n    margin-top: 5px;\n    margin-bottom: 15px;\n  }\n  \n  .jp-codeSnippet-editor-iconurl,\n  .jp-codeSnippet-editor-voicename{\n    display: block;\n    margin-bottom: 20px;\n    margin-left: 2%;\n    width: 80%;\n    height: 32px;\n    font-size: var(--jp-ui-font-size1);\n    border-radius: 2px;\n    -webkit-appearance: none; /* chrome and safari */\n    -moz-appearance: none; /* Mozilla */\n    -ms-appearance: none; /* Internet explorer */\n    appearance: none;\n    color: var(--jp-ui-font-color0);\n    outline: none;\n    background: var(--jp-input-background);\n    box-sizing: border-box;\n    border: var(--jp-border-width) solid var(--jp-border-color1);\n    padding-left: 7px;\n    padding-right: 7px;\n    background-image: url(./icon/jupyter_searcharrowdown.svg);\n    background-repeat: no-repeat;\n    background-position: 95% center;\n    margin-top: 5px;\n  }\n  \n  .jp-codeSnippet-editor-language {\n    display: block;\n    margin-bottom: 20px;\n    margin-left: 2%;\n    width: 176px;\n    height: 32px;\n    font-size: var(--jp-ui-font-size1);\n    border-radius: 2px;\n    -webkit-appearance: none; /* chrome and safari */\n    -moz-appearance: none; /* Mozilla */\n    -ms-appearance: none; /* Internet explorer */\n    appearance: none;\n    color: var(--jp-ui-font-color0);\n    outline: none;\n    background: var(--jp-input-background);\n    box-sizing: border-box;\n    border: var(--jp-border-width) solid var(--jp-border-color1);\n    padding-left: 7px;\n    padding-right: 7px;\n    background-image: url(./icon/jupyter_searcharrowdown.svg);\n    background-repeat: no-repeat;\n    background-position: 95% center;\n    margin-top: 5px;\n  }\n  \n  .jp-codeSnippet-editor-voicename,\n  .jp-codeSnippet-editor-language:hover {\n    background-image: none;\n  }\n  \n  .jp-codeSnippet-editor-templateengine {\n    display: block;\n    margin-bottom: 20px;\n    margin-left: 2%;\n    width: 176px;\n    height: 32px;\n    font-size: var(--jp-ui-font-size1);\n    border-radius: 2px;\n    -webkit-appearance: none; /* chrome and safari */\n    -moz-appearance: none; /* Mozilla */\n    -ms-appearance: none; /* Internet explorer */\n    appearance: none;\n    color: var(--jp-ui-font-color0);\n    outline: none;\n    background: var(--jp-input-background);\n    box-sizing: border-box;\n    border: var(--jp-border-width) solid var(--jp-border-color1);\n    padding-left: 7px;\n    padding-right: 7px;\n    background-image: url(./icon/jupyter_searcharrowdown.svg);\n    background-repeat: no-repeat;\n    background-position: 95% center;\n    margin-top: 5px;\n  }\n  \n  .jp-codeSnippet-editor-templateengine :hover {\n    background-image: none;\n  }\n  \n  .jp-codeSnippet-editor-tagList {\n    list-style: none;\n    margin-left: 2%;\n    margin-bottom: 8px;\n    margin-top: -8px;\n  }\n  \n  .jp-codeSnippet-editor-tag {\n    margin-left: 3px;\n    margin-right: 3px;\n  }\n  \n  .jp-codeSnippet-editor-tag button {\n    cursor: pointer;\n    background: none;\n    border: none;\n    color: var(--jp-ui-font-color2);\n    padding: 0;\n    font-size: var(--jp-ui-font-size1);\n  }\n  \n  .jp-codeSnippet-editor-tag input {\n    border: none;\n    background: transparent;\n  }\n  \n  .jp-codeSnippet-editor-tag.applied-tag button {\n    color: var(--jp-ui-font-color1);\n  }\n  \n  .jp-codeSnippet-editor-tag.unapplied-tag button {\n    color: var(--jp-ui-font-color2);\n  }\n  \n  .jp-codeSnippet-editor-tag.tag.unapplied-tag input {\n    border: none;\n    background: transparent;\n  }\n  \n  .jp-codeSnippet-editor-active {\n    border: 1px solid var(--jp-cell-editor-active-border-color);\n    background-color: var(--jp-input-active-background);\n  }\n  .jp-codeSnippetInputArea {\n    display: flex;\n    flex-direction: column;\n    height: 100%;\n    width: 98.5%;\n    padding-left: 12px;\n  }\n  \n  .jp-codeSnippetInputArea-editor {\n    overflow: auto;\n    margin-left: 2%;\n    margin-right: 3%;\n    margin-top: 5px;\n  }\n  \n  .jp-codeSnippetInput-editor {\n    border: var(--jp-border-width) solid var(--jp-cell-editor-border-color);\n    border-radius: 0px;\n    background: var(--jp-cell-editor-background);\n  }\n  \n  .jp-codeSnippetInput-editor.active {\n    border: var(--jp-border-width) solid var(--jp-cell-editor-active-border-color);\n    box-shadow: var(--jp-input-box-shadow);\n    background-color: var(--jp-cell-editor-active-background);\n  }\n  \n  .jp-codeSnippetInput-editor .CodeMirror.cm-s-jupyter {\n    background: transparent;\n  }\n  \n  .jp-codeSnippetInputArea .saveBtn {\n    width: 10%;\n    background: var(--jp-brand-color1);\n    color: var(--jp-ui-inverse-font-color0);\n    align-self: flex-end;\n    margin-top: 12px;\n    margin-right: 3%;\n    margin-bottom: 12px;\n  }\n  \n  .jp-codeSnippetInputArea .voiceBtn {\n    width: 10%;\n    background: var(--jp-brand-color1);\n    color: var(--jp-ui-inverse-font-color0);\n    align-self: flex-end;\n    margin-top: 12px;\n    margin-right: 3%;\n    margin-bottom: 12px;\n  }\n  \n  /* code snippet create button */\n  .jp-importSnippetBtn,\n  .jp-exportAllSnippetBtn,\n  .jp-refreshSnippetBtn,\n  .jp-createSnippetBtn {\n    cursor: pointer;\n    border: none; \n    background: none;\n    padding: 0px;\n  }\n  \n  /* @import url('~@jupyterlab/codeeditor/style/index.css'); */\n  \n  /* Code Snippet Filter CSS */\n  .jp-codeSnippet-searchbar {\n    margin: 0px 8px;\n  }\n  \n  .jp-codeSnippet-filterTools {\n    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);\n  }\n  \n  mark.jp-codeSnippet-search-bolding {\n    background-color: transparent;\n    font-weight: bold;\n    color: var(--jp-ui-font-color0);\n  }\n  \n  .jp-codeSnippet-filter {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    margin: 10px 10px 0 10px;\n  }\n  \n  .jp-codeSnippet-filter .jp-codeSnippet-filter-btn {\n    align-self: flex-end;\n    padding: 0px;\n    padding-bottom: 10px;\n    border: none;\n    background: none;\n    cursor: pointer;\n    color: var(--jp-brand-color2);\n  }\n  \n  .jp-codeSnippet-filter-arrow-up.idle,\n  .jp-codeSnippet-filter-option.idle {\n    display: none;\n  }\n  \n  .jp-codeSnippet-filter-arrow-up {\n    position: absolute;\n    margin-top: 20px;\n    border: var(--jp-border-width) solid var(--jp-border-color2);\n    border-width: 0 var(--jp-border-width) var(--jp-border-width) 0;\n    padding: 4px;\n    margin-right: 38px;\n    align-self: flex-end;\n    -webkit-transform: rotate(-135deg);\n    transform: rotate(-135deg);\n    background-color: var(--jp-layout-color0);\n  }\n  \n  .jp-codeSnippet-filter-option {\n    border: var(--jp-border-width) solid var(--jp-border-color2);\n    height: 140px;\n    width: 100%;\n    margin-bottom: 10px;\n    overflow: auto;\n  }\n  \n  .jp-codeSnippet-filter-title {\n    text-transform: uppercase;\n    color: var(--jp-ui-font-color2);\n    font-size: var(--jp-ui-font-size1);\n    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);\n    margin: 10px 10px;\n    padding-bottom: 5px;\n  }\n  \n  .jp-codeSnippet-filter-tags {\n    margin: 0px 8px;\n  }\n  \n  .jp-codeSnippet-filter-tag {\n    margin-left: 3px;\n    margin-right: 3px;\n  }\n  \n  .jp-codeSnippet-filter-tag button {\n    cursor: pointer;\n    background: none;\n    border: none;\n    color: var(--jp-ui-font-color2);\n    padding: 0;\n    font-size: var(--jp-ui-font-size1);\n  }\n  \n  .jp-codeSnippet-tools {\n    border-bottom: var(--jp-border-width) solid var(--jp-border-color2);\n  }\n  \n  /* Code Snippet Tags in InputDialog */\n  .jp-codeSnippet-inputTagList {\n    list-style: none;\n  }\n  \n  .jp-codeSnippet-inputTag {\n    margin-left: 8px;\n    margin-right: 8px;\n  }\n  \n  .jp-codeSnippet-inputTag button {\n    cursor: pointer;\n    background: none;\n    border: none;\n    color: var(--jp-ui-font-color2);\n    padding: 0;\n    font-size: var(--jp-ui-font-size1);\n  }\n  \n  .jp-codeSnippet-inputTag input {\n    font-size: var(--jp-ui-font-size1);\n    background: none;\n    border: none;\n    color: var(--jp-ui-font-color2);\n    padding: 0;\n    font-size: var(--jp-ui-font-size1);\n    width: 50px;\n  }\n  \n  .jp-codeSnippet-tags {\n    margin-top: 8px;\n  }\n  \n  /* .jp-codeSnippet-tag,\n  .jp-codeSnippet-inputTag,\n  .jp-codeSnippet-filter-tag {\n    height: 5px;\n  } */\n  \n  /* USER Input Form Style\n  .jp-codeSnippet-form {\n    position: absolute;\n    z-index: 10000;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    top: 0px;\n    left: 0px;\n    margin: 0;\n    padding: 0;\n    width: 100%;\n    height: 100%;\n    background: var(--jp-dialog-background);\n  } */\n  \n  /* .jp-codesnippet-editor-name:required {\n      border-color: #808080;\n      border-width: 3px;\n    } */\n  \n  .jp-codeSnippet-dialog-name-input.touched:invalid,\n  .jp-codeSnippet-dialog-desc-input.touched:invalid,\n  .jp-codeSnippet-dialog-lang-input.touched:invalid,\n  .jp-codeSnippet-editor-name.touched:invalid,\n  .jp-codeSnippet-editor-description.touched:invalid,\n  .jp-codeSnippet-editor-language.touched:invalid {\n    border: var(--jp-border-width) solid var(--jp-error-color1);\n  }\n  \n  .jp-codeSnippet-editor-templateengine \n  .jp-codeSnippet-editor-voicename,\n  .jp-codeSnippet-editor-language.touched:invalid {\n    border: var(--jp-border-width) solid var(--jp-error-color1);\n  }\n  \n  .jp-codeSnippet-dialog-name-input.jp-mod-styled,\n  .jp-codeSnippet-dialog-desc-input.jp-mod-styled,\n  .jp-codeSnippet-dialog-lang-input.jp-mod-styled {\n    margin-bottom: 10px;\n    font-size: var(--jp-ui-font-size1);\n  }\n  \n  .jp-codeSnippet-inputName-validity,\n  .jp-codeSnippet-inputDesc-validity {\n    font-size: var(--jp-ui-font-size0);\n    color: var(--jp-ui-font-color1);\n    margin: 5px;\n    margin-bottom: 8px;\n  }\n  \n  .jp-codeSnippet-editor-metadata .jp-codeSnippet-inputName-validity,\n  .jp-codeSnippet-editor-metadata .jp-codeSnippet-inputDesc-validity {\n    margin-bottom: 20px;\n    margin-top: 5px;\n    margin-left: 3%;\n  }\n  \n  /* 3 Dots Dropdown On Code Snippet */\n  .jp-codeSnippet-options {\n    position: absolute;\n    z-index: 10000;\n    height: 100%;\n    width: 100%;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    margin: 0;\n    background-color: transparent;\n  }\n  \n  .jp-codeSnippet-options.inactive {\n    display: none;\n  }\n  \n  .jp-codeSnippet-more-options-content {\n    width: 183px;\n    font-style: normal;\n    font-weight: normal;\n    font-size: 13px;\n    text-align: left;\n  }\n  \n  .jp-codeSnippet-options-content {\n    background: var(--jp-layout-color1);\n    padding: 10px;\n    border: 1px solid var(--jp-border-color0);\n    width: 180px;\n    box-sizing: border-box;\n    box-shadow: var(--jp-elevation-z1);\n    word-wrap: break-word;\n    border-radius: var(--jp-border-radius);\n    font-size: var(--jp-ui-font-size0);\n    color: var(--jp-ui-font-color1);\n    position: absolute;\n    top: var(--more-options-top);\n    left: var(--more-options-left);\n  }\n  \n  .jp-codeSnippet-options-body {\n    display: flex;\n    align-items: center;\n  }\n  \n  .jp-codeSnippet-more-options-copy {\n    padding-bottom: 5px;\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-copy:hover {\n    background-color: var(--jp-layout-color2);\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-insert {\n    padding-bottom: 5px;\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-insert:hover {\n    background-color: var(--jp-layout-color2);\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-edit {\n    padding-bottom: 5px;\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-edit:hover {\n    background-color: var(--jp-layout-color2);\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-delete {\n    color: var(--jp-error-color0);\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-delete:hover {\n    background-color: var(--jp-layout-color2);\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-export {\n    color: var(--jp-brand-color0);\n    padding-bottom: 5px;\n    cursor: pointer;\n  }\n  \n  .jp-codeSnippet-more-options-export:hover {\n    background-color: var(--jp-layout-color2);\n    cursor: pointer;\n  }\n  \n  .jp-dropdown-delete-button {\n    border: none;\n  }\n  \n  .jp-dropdown-cancel-button {\n    outline: 1px solid var(--jp-brand-color1);\n    outline-offset: 4px;\n  }"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "../node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./base.css */ "../node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./style/icon/dragtab_jupyter.svg":
/*!****************************************!*\
  !*** ./style/icon/dragtab_jupyter.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3csvg width='11' height='17' viewBox='0 0 11 17' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3cpath d='M4.5 14.3281C4.5 15.4395 3.6 16.3489 2.5 16.3489C1.4 16.3489 0.5 15.4395 0.5 14.3281C0.5 13.2166 1.4 12.3073 2.5 12.3073C3.6 12.3073 4.5 13.2166 4.5 14.3281ZM2.5 6.24475C1.4 6.24475 0.5 7.15413 0.5 8.26558C0.5 9.37704 1.4 10.2864 2.5 10.2864C3.6 10.2864 4.5 9.37704 4.5 8.26558C4.5 7.15413 3.6 6.24475 2.5 6.24475ZM2.5 0.182251C1.4 0.182251 0.5 1.09163 0.5 2.20308C0.5 3.31454 1.4 4.22392 2.5 4.22392C3.6 4.22392 4.5 3.31454 4.5 2.20308C4.5 1.09163 3.6 0.182251 2.5 0.182251ZM8.5 4.22392C9.6 4.22392 10.5 3.31454 10.5 2.20308C10.5 1.09163 9.6 0.182251 8.5 0.182251C7.4 0.182251 6.5 1.09163 6.5 2.20308C6.5 3.31454 7.4 4.22392 8.5 4.22392ZM8.5 6.24475C7.4 6.24475 6.5 7.15413 6.5 8.26558C6.5 9.37704 7.4 10.2864 8.5 10.2864C9.6 10.2864 10.5 9.37704 10.5 8.26558C10.5 7.15413 9.6 6.24475 8.5 6.24475ZM8.5 12.3073C7.4 12.3073 6.5 13.2166 6.5 14.3281C6.5 15.4395 7.4 16.3489 8.5 16.3489C9.6 16.3489 10.5 15.4395 10.5 14.3281C10.5 13.2166 9.6 12.3073 8.5 12.3073Z' fill='%23828282'/%3e %3c/svg%3e";

/***/ }),

/***/ "./style/icon/jupyter_searcharrowdown.svg":
/*!************************************************!*\
  !*** ./style/icon/jupyter_searcharrowdown.svg ***!
  \************************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3cpath d='M10.5622 0.464844L5.96549 5.06151L1.36883 0.464844L0.132161 1.70151L5.96549 7.53484L11.7988 1.70151L10.5622 0.464844Z' fill='%23616161'/%3e %3c/svg%3e";

/***/ })

}]);
//# sourceMappingURL=style_index_js.31d428649127ef5c8054.js.map